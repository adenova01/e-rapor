-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Sep 18, 2021 at 08:32 AM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 7.4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `e-rapor`
--

-- --------------------------------------------------------

--
-- Table structure for table `tb_e-rapor`
--

CREATE TABLE `tb_e-rapor` (
  `id_rapor` int(11) NOT NULL,
  `id_siswa` varchar(3) NOT NULL,
  `id_mapel` varchar(50) NOT NULL,
  `deskripsi` text NOT NULL,
  `id_wali_kelas` varchar(3) NOT NULL,
  `nilai_ketuntasan` int(11) NOT NULL,
  `kategori` varchar(1) NOT NULL,
  `nilai` varchar(3) NOT NULL,
  `predikat` varchar(2) NOT NULL,
  `status` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_guru_mapel`
--

CREATE TABLE `tb_guru_mapel` (
  `nip` varchar(25) NOT NULL,
  `id_guru_mapel` int(11) NOT NULL,
  `id_login` int(11) DEFAULT NULL,
  `nama_guru_mapel` varchar(50) NOT NULL,
  `pengampu_mapel` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_guru_mapel`
--

INSERT INTO `tb_guru_mapel` (`nip`, `id_guru_mapel`, `id_login`, `nama_guru_mapel`, `pengampu_mapel`, `alamat`, `created_at`, `updated_at`) VALUES
('20211801', 1, 7, 'coba guru', '1,2', 'asdasdasd', '2021-09-17 18:56:22', '2021-09-17 18:56:41');

-- --------------------------------------------------------

--
-- Table structure for table `tb_jurusan`
--

CREATE TABLE `tb_jurusan` (
  `id` int(11) NOT NULL,
  `kode_jurusan` varchar(10) NOT NULL,
  `nama_jurusan` varchar(30) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_jurusan`
--

INSERT INTO `tb_jurusan` (`id`, `kode_jurusan`, `nama_jurusan`, `created_at`, `updated_at`) VALUES
(1, 'MIA', 'MIA', '2021-09-10 22:06:26', '2021-09-10 22:27:06'),
(2, 'IIS', 'IIS', '2021-09-10 22:06:34', '2021-09-10 22:06:34');

-- --------------------------------------------------------

--
-- Table structure for table `tb_login`
--

CREATE TABLE `tb_login` (
  `id` int(11) NOT NULL,
  `e_mail` varchar(50) NOT NULL,
  `password` text NOT NULL,
  `role` varchar(10) NOT NULL,
  `status` enum('disable','active') DEFAULT 'disable',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_login`
--

INSERT INTO `tb_login` (`id`, `e_mail`, `password`, `role`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin@admin.com', 'eyJpdiI6IjBXKzlhVXpxNkwrSXkreXd5c005c0E9PSIsInZhbHVlIjoianJpTCt4bGxlNWFtaXJmVy9YbHpnUT09IiwibWFjIjoiNTQzMjA5NjQzZjI4NWYxMzgzZDM2OTMyZTkxNDYyOGNkZDhmYTg5ODI1OTFkZDU4YTIyNTgzYTA3ZDIzOGM0ZSIsInRhZyI6IiJ9', 'admin', 'active', '2021-09-04 11:09:57', '2021-09-04 11:09:57'),
(5, 'siswa@email.com', 'eyJpdiI6IkV2eFZsVS90QUdSQlhhdnd5Ukp2Z1E9PSIsInZhbHVlIjoiTGFDMEFlalhjN3JPRDUyQTViblFCQT09IiwibWFjIjoiMWIzNDNmNDNlYjQ1M2NmNDg0NGJjZjNmZDBmYjI5MGE4YzZlNGNhODU1MDNhOGMzMTdlYTMxMDVhYzJkNGQwYSIsInRhZyI6IiJ9', 'siswa', 'active', '2021-09-16 15:28:39', '2021-09-17 19:39:35'),
(7, 'guru@guru.com', 'eyJpdiI6IndHWm8rS2wwbTZVWXczU2pwRTVkMUE9PSIsInZhbHVlIjoiS05vUzZ0ZlZpWW1nY0RLVHRhSndsUT09IiwibWFjIjoiMTdiYjg1OWFjMDViMWNlMDc2NzZiMTkxYmUwZDQ4ZjA0ZTVjNjk4MDM2Njk2NmVhMzY3NTI5NGZiNDlhODdlOSIsInRhZyI6IiJ9', 'guru', 'active', '2021-09-18 01:56:36', '2021-09-17 18:56:41'),
(8, 'walimurid@email.com', 'eyJpdiI6IklsRk5lS2Q1YUtHWkRwbXZLRFZNM3c9PSIsInZhbHVlIjoiWGZ5RUwxakRQdjczenRrNS9mbDNzWHk0cEI1dXlPQjBET1hJM0VCUnc2bz0iLCJtYWMiOiIzZWE2NDFlODgzMGI0ZDE0NjZmZjRmYzdhNTM4YTFmNmViMTQxNjQxNTQ3ZWE5NWI4NDFiOGY1MjE0NWFjYmQ1IiwidGFnIjoiIn0=', 'wali_murid', 'active', '2021-09-18 06:29:10', '2021-09-17 23:29:44');

-- --------------------------------------------------------

--
-- Table structure for table `tb_mapel`
--

CREATE TABLE `tb_mapel` (
  `id` int(11) NOT NULL,
  `kode_mapel` varchar(10) NOT NULL,
  `nama_mapel` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_mapel`
--

INSERT INTO `tb_mapel` (`id`, `kode_mapel`, `nama_mapel`, `created_at`, `updated_at`) VALUES
(1, 'MTK', 'Matematika', '2021-09-11 02:49:57', '2021-09-10 19:49:57'),
(2, 'FSK', 'Fisika', '2021-09-11 02:50:41', '2021-09-10 19:50:41'),
(3, 'BING', 'Bahasa Inggris', '2021-09-11 02:50:55', '2021-09-10 19:50:55'),
(4, 'BINDO', 'Bahasa Indonesia', '2021-09-11 02:51:02', '2021-09-10 19:51:02'),
(5, 'EKNM', 'Ekonomi', '2021-09-11 02:51:11', '2021-09-10 19:51:11'),
(6, 'PA', 'Pendidikan Agama', '2021-09-11 02:51:22', '2021-09-10 19:51:22'),
(7, 'PPKN', 'PPKn', '2021-09-11 02:51:30', '2021-09-10 19:51:30'),
(8, 'SSLG', 'Sosiologi', '2021-09-11 02:51:37', '2021-09-10 19:51:37'),
(9, 'SJRH', 'Sejarah', '2021-09-11 02:51:45', '2021-09-10 19:51:45'),
(10, 'TIK', 'TIK', '2021-09-11 02:51:51', '2021-09-10 19:51:51'),
(11, 'KMA', 'Kimia', '2021-09-11 02:51:59', '2021-09-10 19:51:59'),
(12, 'SBD', 'Seni Budaya', '2021-09-11 02:52:10', '2021-09-10 19:52:10'),
(13, 'SJIND', 'Sejarah Indonesia', '2021-09-11 02:52:38', '2021-09-10 19:52:38'),
(14, 'BSI', 'Bahasa & Sastra Inggris', '2021-09-11 02:52:53', '2021-09-10 19:52:53'),
(15, 'PRAK', 'Prakarya', '2021-09-11 02:53:13', '2021-09-10 19:53:13'),
(16, 'PAI', 'Pendidikan Agama Islam', '2021-09-11 02:53:26', '2021-09-10 19:53:26'),
(17, 'GRGF', 'Geografi', '2021-09-11 02:53:55', '2021-09-10 19:53:55'),
(18, 'PNJS', 'Penjas', '2021-09-11 02:54:04', '2021-09-10 19:54:04'),
(19, 'BP/BK', 'BP/BK', '2021-09-11 02:54:16', '2021-09-10 19:54:16'),
(20, 'PAK', 'Pendidian Agama Kristen & Budi Pekerti', '2021-09-11 02:54:33', '2021-09-10 19:54:33');

-- --------------------------------------------------------

--
-- Table structure for table `tb_nilai`
--

CREATE TABLE `tb_nilai` (
  `id_nilai` int(11) NOT NULL,
  `id_guru_mapel` varchar(25) NOT NULL,
  `id_mapel` varchar(50) NOT NULL,
  `id_siswa` varchar(50) NOT NULL,
  `nama_nilai` varchar(30) NOT NULL,
  `nilai` double NOT NULL,
  `nilai_huruf` char(2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_nilai`
--

INSERT INTO `tb_nilai` (`id_nilai`, `id_guru_mapel`, `id_mapel`, `id_siswa`, `nama_nilai`, `nilai`, `nilai_huruf`, `created_at`, `updated_at`) VALUES
(1, '1', '1', '1', 'Tugas', 78, 'B+', '2021-09-18 05:51:14', NULL),
(2, '1', '2', '1', 'UTS', 80, 'A', '2021-09-18 05:51:47', NULL),
(3, '1', '1', '2', 'Tugas', 54, 'C', '2021-09-18 05:53:53', NULL),
(4, '1', '2', '2', 'UTS', 56, 'C+', '2021-09-18 05:55:04', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tb_peringkat`
--

CREATE TABLE `tb_peringkat` (
  `id_peringkat` int(11) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `rata_rata` double NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_peringkat`
--

INSERT INTO `tb_peringkat` (`id_peringkat`, `id_siswa`, `rata_rata`, `created_at`, `updated_at`) VALUES
(1, 1, 79, '2021-09-18 05:51:47', '2021-09-17 22:51:47'),
(2, 2, 55, '2021-09-18 05:55:04', '2021-09-17 22:55:04');

-- --------------------------------------------------------

--
-- Table structure for table `tb_rombel`
--

CREATE TABLE `tb_rombel` (
  `id` int(11) NOT NULL,
  `kode_rombel` varchar(1) NOT NULL,
  `nama_rombel` varchar(50) NOT NULL,
  `id_jurusan` int(11) NOT NULL,
  `kelas` varchar(10) NOT NULL,
  `id_mapel` varchar(30) NOT NULL,
  `tahun_ajar` char(10) NOT NULL,
  `semester` enum('ganjil','genap') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_rombel`
--

INSERT INTO `tb_rombel` (`id`, `kode_rombel`, `nama_rombel`, `id_jurusan`, `kelas`, `id_mapel`, `tahun_ajar`, `semester`, `created_at`, `updated_at`) VALUES
(1, '1', 'MIA 1', 1, 'X', '1,2', '2021-2022', 'ganjil', '2021-09-17 18:57:22', '2021-09-17 18:57:22');

-- --------------------------------------------------------

--
-- Table structure for table `tb_siswa`
--

CREATE TABLE `tb_siswa` (
  `nis` varchar(25) NOT NULL,
  `id_siswa` int(11) NOT NULL,
  `id_login` int(11) DEFAULT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `kelas` varchar(50) NOT NULL,
  `jurusan` varchar(50) NOT NULL,
  `rombel_id` varchar(50) DEFAULT NULL,
  `alamat` varchar(50) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_siswa`
--

INSERT INTO `tb_siswa` (`nis`, `id_siswa`, `id_login`, `nama_siswa`, `kelas`, `jurusan`, `rombel_id`, `alamat`, `created_at`, `updated_at`) VALUES
('202108001', 1, 5, 'adenova', 'X', '1', '1', 'simo', '2021-09-17 08:08:54', '2021-09-17 19:39:35'),
('202108002', 2, NULL, 'doni', 'XII', '1', '1', 'asdasdasd', '2021-09-17 08:48:29', '2021-09-17 18:57:45');

-- --------------------------------------------------------

--
-- Table structure for table `tb_wali_kelas`
--

CREATE TABLE `tb_wali_kelas` (
  `nip` varchar(25) NOT NULL,
  `id_wali_kelas` int(11) NOT NULL,
  `id_login` int(11) DEFAULT NULL,
  `pengampu_kelas` varchar(50) NOT NULL,
  `pengampu_jurusan` varchar(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tb_wali_murid`
--

CREATE TABLE `tb_wali_murid` (
  `id_wali_murid` int(11) NOT NULL,
  `nama_wali_murid` varchar(50) NOT NULL,
  `id_siswa` varchar(50) DEFAULT NULL,
  `alamat` varchar(100) NOT NULL,
  `id_login` varchar(10) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_wali_murid`
--

INSERT INTO `tb_wali_murid` (`id_wali_murid`, `nama_wali_murid`, `id_siswa`, `alamat`, `id_login`, `created_at`, `updated_at`) VALUES
(1, 'bapak', '2', 'simo jawar', '8', '2021-09-18 06:29:37', '2021-09-17 23:29:44');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tb_e-rapor`
--
ALTER TABLE `tb_e-rapor`
  ADD PRIMARY KEY (`id_rapor`);

--
-- Indexes for table `tb_guru_mapel`
--
ALTER TABLE `tb_guru_mapel`
  ADD PRIMARY KEY (`id_guru_mapel`);

--
-- Indexes for table `tb_jurusan`
--
ALTER TABLE `tb_jurusan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_login`
--
ALTER TABLE `tb_login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_mapel`
--
ALTER TABLE `tb_mapel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_nilai`
--
ALTER TABLE `tb_nilai`
  ADD PRIMARY KEY (`id_nilai`);

--
-- Indexes for table `tb_peringkat`
--
ALTER TABLE `tb_peringkat`
  ADD PRIMARY KEY (`id_peringkat`);

--
-- Indexes for table `tb_rombel`
--
ALTER TABLE `tb_rombel`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tb_siswa`
--
ALTER TABLE `tb_siswa`
  ADD PRIMARY KEY (`id_siswa`);

--
-- Indexes for table `tb_wali_kelas`
--
ALTER TABLE `tb_wali_kelas`
  ADD PRIMARY KEY (`id_wali_kelas`);

--
-- Indexes for table `tb_wali_murid`
--
ALTER TABLE `tb_wali_murid`
  ADD PRIMARY KEY (`id_wali_murid`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
