<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\API\ApiController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::get('/userDetail/{id}', [ApiController::class, 'getUserDetail']);
Route::get('/deleteUser/{id}', [ApiController::class, 'deleteUser']);
Route::get('/decryptPass/{encryptPass}', [ApiController::class, 'decrypt']);

Route::get('/getUrutSiswa', [ApiController::class, 'getJumlahSiswa']);
Route::get('/siswaDetail/{id}', [ApiController::class, 'getDetilSiswa']);
Route::get('/deleteSiswa/{id}', [ApiController::class, 'deleteSiswa']);
Route::get('/detilMapelSiswa/{id}', [ApiController::class, 'detilMapelSiswa']);

Route::get('/detilMapel/{id}', [ApiController::class, 'detilMapel']);
Route::get('/deleteMapel/{id}', [ApiController::class, 'deleteMapel']);
Route::get('/allMapel/{id}', [ApiController::class, 'getMapel']);

Route::get('/detilGuru/{id}', [ApiController::class, 'detilGuru']);
Route::get('/deleteGuru/{id}', [ApiController::class, 'deleteGuru']);

Route::get('/detilWaliKelas/{id}', [ApiController::class, 'detilWaliKelas']);
Route::get('/deleteWaliKelas/{id}', [ApiController::class, 'deleteWaliKelas']);

Route::get('/manageUser/{role}', [ApiController::class, 'manageUser']);
Route::get('/deactivasi/{id}/{role}', [ApiController::class, 'deactivasiUser']);

Route::get('/getDetilJurusan/{id}', [ApiController::class, 'detilJurusan']);
Route::get('/deleteJurusan/{id}', [ApiController::class, 'deleteJurusan']);

Route::get('/getDetilRombel/{id}', [ApiController::class, 'detilRombel']);
Route::get('/hapusRombel/{id}', [ApiController::class, 'hapusRombel']);

Route::get('/getDetilMapel/{id}', [ApiController::class, 'getDetilMapel']);
Route::post('/saveNilai', [ApiController::class, 'saveNilai']);
Route::post('/updateNilai/{id}', [ApiController::class, 'updateNilai']);
Route::get('/NilaiSiswaDetil/{mapel_id}/{siswa_id}', [ApiController::class, 'nilaiDetil']);
Route::get('/getNilaiSiswa/{siswa_id}', [ApiController::class, 'nilaiSiswa']);

Route::post('/saveRapor', [ApiController::class, 'saveRapor']);
Route::get('/updateStatus/{id}', [ApiController::class, 'updateStatus']);
Route::get('/setPeringkat', [ApiController::class, 'setPeringkat']);

Route::get('/getWaliMurid/{id}', [ApiController::class, 'getWaliMurid']);
Route::get('/hapusWaliMurid/{id}', [ApiController::class, 'deleteWaliMurid']);
