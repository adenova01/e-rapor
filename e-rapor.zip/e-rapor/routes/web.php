<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\ERaporController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\SiswaController;
use App\Http\Controllers\MapelController;
use App\Http\Controllers\GuruController;
use App\Http\Controllers\WaliKelasController;
use App\Http\Controllers\JurusanController;
use App\Http\Controllers\RombelController;
use App\Http\Controllers\NilaiController;
use App\Http\Controllers\PeringkatController;
use App\Http\Controllers\WaliMuridController;
use App\Models\Mapel;
use GuzzleHttp\Middleware;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('page.login');
});

Route::post('/cekLogin', [AuthController::class, 'cekLogin']);
Route::get('/logout', [AuthController::class, 'logout']);
Route::get('/register', [AuthController::class, 'register']);
Route::post('/register/save', [AuthController::class, 'register_simpan']);
Route::get('/register/verif/{id}', [AuthController::class, 'activasiAkun']);

Route::group(['middleware' => ['check']], function(){

    Route::get('/dashboard', [HomeController::class, 'dashboard']);

    Route::get('/userSetting', [AuthController::class, 'userSetting']);
    Route::post('/changePass/{id}', [AuthController::class, 'changePass']);
    
    Route::get('/pengguna', [AuthController::class, 'addUser']);
    Route::post('/savePengguna', [AuthController::class, 'saveUser']);
    Route::post('/editPengguna', [AuthController::class, 'updateUser']);
    
    Route::get('/siswa', [SiswaController::class, 'index']);
    Route::post('/saveSiswa', [SiswaController::class, 'store']);
    Route::post('/addRombel', [SiswaController::class, 'addRombel']);
    Route::post('/editSiswa', [SiswaController::class, 'update']);
    Route::post('/aktivasiSiswa', [SiswaController::class, 'aktivasi']);
    
    Route::get('/mapel', [MapelController::class, 'index']);
    Route::post('/saveMapel', [MapelController::class, 'store']);
    Route::post('/editMapel', [MapelController::class, 'update']);
    
    Route::get('/guru', [GuruController::class, 'index']);
    Route::post('/saveGuru', [GuruController::class, 'store']);
    Route::post('/editGuru', [GuruController::class, 'update']);
    Route::post('/aktivasiGuru', [GuruController::class, 'aktivasi']);
    
    Route::get('/waliKelas', [WaliKelasController::class, 'index']);
    Route::post('/saveWaliKelas', [WaliKelasController::class, 'store']);
    Route::post('/editWaliKelas', [WaliKelasController::class, 'update']);
    Route::post('/aktivasiWaliKelas', [WaliKelasController::class, 'aktivasi']);

    Route::get('/jurusan', [JurusanController::class, 'index']);
    Route::post('/addJurusan', [JurusanController::class, 'store']);
    Route::post('/editJurusan', [JurusanController::class, 'update']);

    Route::get('/rombel', [RombelController::class, 'index']);
    Route::post('/saveRombel', [RombelController::class, 'store']);
    Route::post('/editRombel', [RombelController::class, 'update']);
    Route::get('/detilrombel/{id}', [RombelController::class, 'detilRombel']);

    Route::get('/nilai', [NilaiController::class, 'index']);
    Route::get('/isiNilai/{id}', [NilaiController::class, 'IsiNilai']);
    Route::get('/detilNilai/{id_siswa}', [NilaiController::class, 'detilNilai']);

    Route::get('/rapor', [ERaporController::class, 'index']);
    Route::get('/rapor/lihat/{id}', [ERaporController::class, 'lihatRapor']);
    Route::get('/rapor/download/{id}', [ERaporController::class, 'downloadRapor']);
    Route::get('/rapor/isi_nilai/{id}', [ERaporController::class, 'isiRapor']);

    Route::get('/peringkat', [PeringkatController::class, 'index']);

    Route::get('/wali_murid',[WaliMuridController::class, 'index']);
    Route::get('/wali_murid/detil/{id}',[WaliMuridController::class, 'show']);
    Route::post('/wali_murid/save',[WaliMuridController::class, 'store']);
    Route::post('/wali_murid/update',[WaliMuridController::class, 'update']);
    Route::post('/aktivasiWaliMurid',[WaliMuridController::class, 'aktivasi']);
    
});