<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WaliMurid extends Model
{
    use HasFactory;
    protected $table = "tb_wali_murid";
    protected $fillable = ['id_wali_murid','nama_wali_murid','id_siswa','alamat','id_login'];
}
