<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Nilai extends Model
{
    use HasFactory;
    protected $table = 'tb_nilai';
    protected $fillable = ['id_nilai','id_guru_mapel','id_mapel','id_siswa','nama_nilai','nilai','nilai_huruf'];
}
