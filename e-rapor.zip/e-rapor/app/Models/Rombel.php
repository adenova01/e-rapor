<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Rombel extends Model
{
    use HasFactory;
    protected $table = "tb_rombel";
    protected $fillable = ['id','kode_rombel','nama_rombel','id_jurusan','kelas','id_siswa','id_wali_kelas','id_mapel','tahun_ajar','semester'];
}
