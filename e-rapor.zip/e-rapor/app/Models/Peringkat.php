<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Peringkat extends Model
{
    use HasFactory;

    protected $table = "tb_peringkat";
    protected $fillable = ['id_peringkat','id_siswa','rata_rata','created_at','updated_at'];
}
