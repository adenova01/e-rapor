<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class e_rapor extends Model
{
    use HasFactory;
    protected $table = "tb_e-rapor";
    protected $fillable = ['id_rapor','id_siswa','id_mapel','deskripsi','id_wali_kelas','nilai_ketuntasan','kategori','nilai','predikat','status'];
}
