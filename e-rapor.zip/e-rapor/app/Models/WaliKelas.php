<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class WaliKelas extends Model
{
    use HasFactory;
    protected $table = "tb_wali_kelas";
    protected $fillable = ['nip','id_wali_kelas','id_login','pengampu_kelas','pengampu_jurusan'];
}
