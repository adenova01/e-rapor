<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Guru extends Model
{
    use HasFactory;
    protected $table = "tb_guru_mapel";
    protected $fillable = ['nip','id_guru_mapel','nama_guru_mapel','pengampu_mapel','alamat'];
}
