<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use App\Http\Controllers\PeringkatController;
use App\Models\e_rapor;
use Illuminate\Http\Request;
use App\Models\Login;
use App\Models\Siswa;
use App\Models\Mapel;
use App\Models\Guru;
use App\Models\WaliKelas;
use App\Models\Jurusan;
use App\Models\Nilai;
use App\Models\Rombel;
use App\Models\WaliMurid;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\DB;

class ApiController extends Controller
{
    /* ------------*/
    // user
    /*--------------*/ 

    public function getUserDetail($id)
    {
        $user = Login::where(['id' => $id])->first();
        return response()->json($user);
    }

    public function encrypt($string)
    {
        $encrypted = Crypt::encrypt($string);
        return response()->json($encrypted);
    }

    public function decrypt($encryptValue)
    {
        try {
            $decrypted = Crypt::decrypt($encryptValue);
            return response()->json($decrypted);
        } catch (DecryptException $e) {
            return response()->json($e);
        }
    }

    public function deleteUser($id)
    {
        $user = Login::find($id);

        $response = [
            'data' => $user,
            'status' => 'sukses'
        ];

        $user->delete();

        return response()->json($response);
    }

    public function manageUser($role)
    {
        switch ($role) {
            case 'admin':
                
                break;

            case 'siswa':
                $data_role = Siswa::where('id_login', null)->get();
                break;
            
            case 'guru':
                $data_role = Guru::where('id_login', null)->get();
                break;
            
            case 'wali_kelas':
                // $data_role = WaliKelas::all();
                $data_role = DB::table('tb_wali_kelas')
                                ->join('tb_guru_mapel','tb_wali_kelas.nip','=','tb_guru_mapel.nip')
                                ->get();
                break;
                
            case 'wali_murid':
                $data_role = WaliMurid::where('id_login', null)->get();
                break;
        }

        return response()->json($data_role);
    }

    public function deactivasiUser($id_login, $role)
    {
        switch ($role) {
            case 'admin':
                
                break;

            case 'siswa':
                $siswa = Siswa::where('id_login',$id_login);
                $login = Login::where('id',$id_login);

                $siswa->update(['id_login' => null]);
                $login->update(['status' => 'disable']);

                $response = [
                    'status' => 'sukses',
                    'email' => $login->get('e_mail')
                ];
                break;
            
            case 'guru':
                $guru = Guru::where('id_login',$id_login);
                $login = Login::where('id',$id_login);

                $guru->update(['id_login' => null]);
                $login->update(['status' => 'disable']);

                $response = [
                    'status' => 'sukses',
                    'email' => $login->get('e_mail')
                ];

                break;
            
            case 'wali_kelas':
                $wali_kelas = WaliKelas::where('id_login',$id_login);
                $login = Login::where('id',$id_login);

                $wali_kelas->update(['id_login' => null]);
                $login->update(['status' => 'disable']);

                $response = [
                    'status' => 'sukses',
                    'email' => $login->get('e_mail')
                ];
                break;
                
            case 'wali_murid':
                $wali_murid = WaliMurid::where('id_login',$id_login);
                $login = Login::where('id',$id_login);

                $wali_murid->update(['id_login' => null]);
                $login->update(['status' => 'disable']);

                $response = [
                    'status' => 'sukses',
                    'email' => $login->get('e_mail')
                ];
                break;
        }

        return response()->json($response);
    }

    /* ------------*/
    // siswa
    /*--------------*/ 

    public function getJumlahSiswa()
    {
        $count_siswa = Siswa::count();
        return response()->json($count_siswa);
    }

    public function getDetilSiswa($id)
    {
        $siswa = Siswa::where(['id_siswa' => $id])->first();
        return response()->json($siswa);
    }

    public function deleteSiswa($id)
    {
        $siswa = Siswa::where(['id_siswa' => $id]);
        
        $response = [
            'nama' => $siswa->get('nama_siswa'),
            'status' => 'sukses'
        ];

        $siswa->delete();

        return response()->json($response);
    }

    /* ------------*/
    // mapel
    /*--------------*/ 

    public function detilMapel($id)
    {
        $mapel = Mapel::find($id);

        return response()->json($mapel);
    }

    public function deleteMapel($id)
    {
        $mapel = Mapel::find($id);

        $response = [
            'nama_mapel' => $mapel->nama_mapel,
            'status' => 'sukses'
        ];

        $mapel->delete();

        return response()->json($response);
    }

    public function getMapel($id)
    {
        $siswa = Siswa::where('id_siswa',$id)->first();
        $rombel = Rombel::where('id', $siswa->rombel_id)->first();
        $id_mapel = explode(',',$rombel->id_mapel);
        for($i=0; $i<count($id_mapel); $i++){
            $mapel[$i] = Mapel::where('id',$id_mapel[$i])->first();
        }
        return response()->json($mapel);
    }

    /* ------------*/
    // guru
    /*--------------*/

    public function detilGuru($id)
    {
        $guru = Guru::where('id_guru_mapel', $id)->first();

        return response()->json($guru);
    }

    public function deleteGuru($id)
    {
        $guru = Guru::where('id_guru_mapel', $id);

        $response = [
            'nama_guru' => $guru->get('nama_guru_mapel'),
            'status' => 'sukses'
        ];

        $guru->delete();

        return response()->json($response);
    }

    public function detilWaliKelas($id)
    {
        $wali_kelas = WaliKelas::where('id_wali_kelas', $id)->first();

        return response()->json($wali_kelas);
    }

    public function deleteWaliKelas($id)
    {
        $wali_kelas = WaliKelas::where('id_wali_kelas', $id);

        $response = [
            'nama_guru' => $wali_kelas->get('nip'),
            'status' => 'sukses'
        ];

        $wali_kelas->delete();

        return response()->json($response);
    }

    /* ------------*/
    // guru
    /*--------------*/

    public function detilJurusan($id)
    {
        $jurusan = Jurusan::where('id',$id)->first();

        return response()->json($jurusan);
    }

    public function deleteJurusan($id)
    {
        $jurusan = Jurusan::find($id);
        $jurusan->delete();

        $response = [
            'status' => 'sukses'
        ];

        return response()->json($response);
    }

    /* ------------*/
    // rombel
    /*--------------*/ 

    public function detilRombel($id)
    {
        $rombel = Rombel::find($id);
        return response()->json($rombel);
    }

    public function hapusRombel($id)
    {
        $rombel = Rombel::find($id);
        $rombel->delete();
        
        $response = [
            'status' => 'sukses'
        ];

        return response()->json($response);
    }

    /* ------------*/
    // nilai
    /*--------------*/

    public function getDetilMapel($id)
    {
        $mapel = Mapel::where('id',$id)->first();
        return response()->json($mapel);
    }

    public function saveNilai()
    {
        $id = Nilai::max('id_nilai');

        if($id != null){
            $id += 1;
        } else {
            $id = 1;
        }

        $data = [
            'id_nilai' => $id,
            'id_guru_mapel' => request()->post('id_guru_mapel'),
            'id_mapel' => request()->post('id_mapel'),
            'id_siswa' => request()->post('id_siswa'),
            'nama_nilai' => request()->post('nama_nilai'),
            'nilai' => request()->post('nilai_angka'),
            'nilai_huruf' => request()->post('nilai_huruf')
        ];

        Nilai::insert($data);

        $peringkat = $this->setPeringkat(request()->post('id_siswa'));

        $response = [
            'status' => 'sukses',
            'data' => $peringkat
        ];

        return response()->json($response);
    }

    public function setPeringkat($id_siswa)
    {
        $data = PeringkatController::savePeringkat($id_siswa);
        return $data;
    }

    public function updateNilai($id)
    {
        $nilai = Nilai::where('id_nilai', $id);

        $data = [
            'id_guru_mapel' => request()->post('id_guru_mapel'),
            'id_mapel' => request()->post('id_mapel'),
            'id_siswa' => request()->post('id_siswa'),
            'nama_nilai' => request()->post('nama_nilai'),
            'nilai' => request()->post('nilai_angka'),
            'nilai_huruf' => request()->post('nilai_huruf')
        ];

        $nilai->update($data);

        $response = [
            'status' => 'sukses'
        ];

        return response()->json($response);
    }

    public function nilaiDetil($mapel_id, $siswa_id)
    {
        $nilai = Nilai::where(['id_mapel' => $mapel_id, 'id_siswa' => $siswa_id])->first();

        if($nilai != null){
            $response = [
                'status' => 'sukses',
                'data' => $nilai
            ];
        } else {
            $response = [
                'status' => 'gagal',
                'data' => $nilai
            ];
        }
        return response()->json($response);
    }

    public function nilaiSiswa($id)
    {
        // $nilai = Nilai::where('id_siswa',$id)->get();
        $nilai = DB::table('tb_nilai')
                    ->join('tb_mapel','tb_nilai.id_mapel','=','tb_mapel.id')
                    ->where('tb_nilai.id_siswa',$id)
                    ->get();

        return response()->json($nilai);
    }

    /* ------------*/
    // rapor
    /*--------------*/

    public function saveRapor()
    {
        $id = e_rapor::max('id_rapor');

        if($id == null){
            $id = 1;
        } else {
            $id += 1;
        }

        $data = [
            'id_rapor' => $id,
            'id_siswa' => request()->post('id_siswa'),
            'id_mapel' => request()->post('id_mapel'),
            'deskripsi' => request()->post('deskripsi'),
            'id_wali_kelas' => request()->post('id_wali_kelas'),
            'nilai_ketuntasan' => request()->post('nilai_ketuntasan'),
            'kategori' => request()->post('kategori'),
            'nilai' => request()->post('nilai'),
            'predikat' => request()->post('predikat'),
            'status' => 'sedang di kerjakan'
        ];

        e_rapor::create($data);

        $response = [
            'status' => 'sukses'
        ];

        return response()->json($response);
    }

    public function updateStatus($id_siswa)
    {
        $rapor = e_rapor::where('id_siswa',$id_siswa);
        $rapor->update(['status' => 'selesai']);

        $response = [
            'status' => 'sukses'
        ];

        return response()->json($response);
    }

    /* ------------*/
    // wali murid
    /*--------------*/

    public function getWaliMurid($id)
    {
        $wali_murid = WaliMurid::where('id_wali_murid',$id)->first();

        return response()->json($wali_murid);
    }

    public function deleteWaliMurid($id)
    {
        $wali_murid = WaliMurid::where(['id_wali_murid' => $id]);
        $id_login = WaliMurid::where(['id_wali_murid' => $id])->get('id_login');

        if($id_login[0]->id_login != null){
            $login = Login::where('id', $id_login[0]->id_login);
            $login->delete();
        }
        
        $wali_murid->delete();

        $response = [
            'status' => 'sukses'
        ];
        
        return response()->json($response);
    }
}
