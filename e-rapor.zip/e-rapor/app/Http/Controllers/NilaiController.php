<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use App\Models\Mapel;
use App\Models\Nilai;
use App\Models\Siswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class NilaiController extends Controller
{
    public function index()
    {
        if(session('role') == 'siswa'){
            $siswa_rombel = DB::table('tb_siswa')
                        ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                        ->join('tb_jurusan','tb_siswa.jurusan','=','tb_jurusan.id')
                        ->where('tb_siswa.id_siswa',session('id_user'))
                        ->get();
        } else if(session('role') == 'wali_murid'){
            $siswa_rombel = DB::table('tb_siswa')
                        ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                        ->join('tb_jurusan','tb_siswa.jurusan','=','tb_jurusan.id')
                        ->where('tb_siswa.id_siswa',session('id_siswa'))
                        ->get();
        } else {
            $siswa_rombel = DB::table('tb_siswa')
                        ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                        ->join('tb_jurusan','tb_siswa.jurusan','=','tb_jurusan.id')
                        ->get();
        }

        $slug = "nilai";
        return view('page.nilai', compact('slug','siswa_rombel'));
    }

    public function IsiNilai($id)
    {
        $detil_siswa = DB::table('tb_siswa')
                ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                ->join('tb_jurusan','tb_siswa.jurusan','=','tb_jurusan.id')
                ->where('tb_siswa.id_siswa', $id)
                ->first();
        
        $status_nilai = Nilai::where(['id_siswa' => $id])->get();

        if(session('role') == 'guru'){

            $guru_mapel = Guru::where('nip',session('nip'))->first();
            $data_mapel_rombel = explode(',',$detil_siswa->id_mapel);
            $data_mapel_guru = explode(',',$guru_mapel->pengampu_mapel);
            $tampil_mapel = "";

            for ($i=0; $i < count($data_mapel_rombel); $i++) { 
                for ($j=0; $j < count($data_mapel_guru); $j++) { 
                    if($data_mapel_rombel[$i] == $data_mapel_guru[$j]){
                        $tampil_mapel .= $data_mapel_guru[$j].' ';
                    }
                }
            }
            $a = explode(' ',trim($tampil_mapel));
            
            for ($i=0; $i < count($a); $i++) { 
                $detil_mapel[$i] = Mapel::where('id',$a[$i])->first();
            }
        }

        $slug = "nilai";
        return view('page.isi_nilai', compact('slug','detil_siswa','detil_mapel','status_nilai'));
        // dd($status_nilai);
    }

    public function detilNilai($id_siswa)
    {
        $slug = "nilai";
        // $detil_nilai = Nilai::where('id_siswa',$id_siswa)->get();
        $detil_nilai = DB::table('tb_nilai')
                        ->join('tb_mapel','tb_nilai.id_mapel','=','tb_mapel.id')
                        ->where('tb_nilai.id_siswa',$id_siswa)
                        ->get();
        
        $nama_siswa = Siswa::where('id_siswa',$id_siswa)->first();
        // dd($detil_nilai);
        return view('page.detil_nilai',compact('slug','detil_nilai','nama_siswa'));
    }
}