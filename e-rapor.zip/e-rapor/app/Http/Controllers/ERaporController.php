<?php

namespace App\Http\Controllers;

use App\Models\e_rapor;
use App\Models\Siswa;
use App\Models\WaliKelas;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use PDF;

class ERaporController extends Controller
{
    public function index()
    {
        // $siswa_rapor = [];
        if(session('role') == 'wali_kelas'){
            $walas = WaliKelas::where('id_wali_kelas',session('id_user'))->first();

            if($walas != null){
                $siswa_rapor = Siswa::where([
                    'kelas' => $walas->pengampu_kelas, 
                    'jurusan' => $walas->pengampu_jurusan
                ])->get();
            } else {
                $siswa_rapor = null;
            }
        } else if(session('role') == 'siswa'){
            $rapor = e_rapor::where('id_siswa', session('id_user'))->first();
            if($rapor != null){
                $siswa_rapor = Siswa::where('id_siswa', session('id_user'))->get();
            } else {
                $siswa_rapor = [];
            }
        } else if(session('role') == 'wali_murid'){
            $rapor = e_rapor::where('id_siswa', session('id_siswa'))->first();
            if($rapor != null){
                $siswa_rapor = Siswa::where('id_siswa', session('id_siswa'))->get();
            } else {
                $siswa_rapor = [];
            }
        } else if(session('role') == 'guru' || session('role') == 'admin'){
            $siswa_rapor = Siswa::all();
        }
        
        
        // $status_rapor = e_rapor::get();
        $status_rapor = DB::table('tb_e-rapor')
                        ->selectRaw('status, id_siswa')
                        ->groupBy('id_siswa','status')
                        ->get();

        // dd($siswa_rapor);
        $slug = 'rapor';
        return view('page.rapor',compact('slug','siswa_rapor','status_rapor'));
    }

    public function lihatRapor($id_siswa)
    {
        $walas = DB::table('tb_wali_kelas')->join('tb_guru_mapel','tb_wali_kelas.nip','=','tb_guru_mapel.nip')
                    ->where('tb_wali_kelas.id_wali_kelas',session('id_user'))
                    ->first();

        $siswa = DB::table('tb_siswa')
                    ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                    ->where('tb_siswa.id_siswa',$id_siswa)
                    ->first();

        $data_rapor = DB::table('tb_e-rapor')
                        ->join('tb_mapel','tb_e-rapor.id_mapel','=','tb_mapel.id')
                        ->where('id_siswa',$id_siswa)
                        ->get();

        $nilai_tuntas = e_rapor::where('id_siswa',$id_siswa)->first('nilai_ketuntasan');
        $nilai_ketuntasan = '';
        
        if($nilai_tuntas != null){
            $nilai_ketuntasan = $nilai_tuntas->nilai_ketuntasan;
        }

        $tanggal = new \DateTime();
        $tglnya = $tanggal->format('d F Y');

        $pdf = PDF::loadView('layout.rapor', compact('siswa','tglnya','walas','data_rapor','nilai_ketuntasan'));
        return $pdf->stream();
    }

    public function downloadRapor($id_siswa)
    {
        $walas = DB::table('tb_wali_kelas')->join('tb_guru_mapel','tb_wali_kelas.nip','=','tb_guru_mapel.nip')
                    ->where('tb_wali_kelas.id_wali_kelas',session('id_user'))
                    ->first();

        $siswa = DB::table('tb_siswa')
                    ->join('tb_rombel','tb_siswa.rombel_id','=','tb_rombel.id')
                    ->where('tb_siswa.id_siswa',$id_siswa)
                    ->first();

        $data_rapor = DB::table('tb_e-rapor')
                        ->join('tb_mapel','tb_e-rapor.id_mapel','=','tb_mapel.id')
                        ->where('id_siswa',$id_siswa)
                        ->get();

        $nilai_tuntas = e_rapor::where('id_siswa',$id_siswa)->first('nilai_ketuntasan');
        $nilai_ketuntasan = '';
        
        if($nilai_tuntas != null){
            $nilai_ketuntasan = $nilai_tuntas->nilai_ketuntasan;
        }

        $tanggal = new \DateTime();
        $tglnya = $tanggal->format('d F Y');

        $nama_rapor = 'Rapor_'.$siswa->nis.'_'.$siswa->nama_siswa;

        $pdf = PDF::loadView('layout.rapor', compact('siswa','tglnya','walas','data_rapor','nilai_ketuntasan'));
        return $pdf->download($nama_rapor);
    }

    public function isiRapor($id_siswa)
    {
        $slug = "rapor";
        $siswa = Siswa::where('id_siswa', $id_siswa)->first();

        return view('page.isi_rapor', compact('slug','siswa'));
    }
}
