<?php

namespace App\Http\Controllers;

use App\Models\Guru;
use Illuminate\Http\Request;
use App\Models\Login;
use App\Models\Siswa;
use App\Models\WaliKelas;
use App\Models\WaliMurid;
use Illuminate\Contracts\Encryption\DecryptException;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;
use App\Mail\VerificationEmail;

class AuthController extends Controller
{
    public function encrypt($string)
    {
        $encrypted = Crypt::encrypt($string);
        return $encrypted;
    }

    public function decrypt($encryptValue)
    {
        try {
            $decrypted = Crypt::decrypt($encryptValue);
            return $decrypted;
        } catch (DecryptException $de) {
            return '<script>alert('.$de.')</script>';
        }
    }

    public function register()
    {
        return view('page.register');
    }

    public function register_simpan()
    {
        $cek_siswa = Siswa::where('nis',request()->post('nisn'))->first();
        if($cek_siswa == null){
            return back()->with('message', 'Gagal NISN tidak ada dalam sistem kami');
        }

        $id = Login::max('id');

        if($id == null){
            $id = 1;
        } else {
            $id += 1 ;
        }

        $data_login = [
            'id' => $id,
            'e_mail' => request()->post('email'),
            'password' => encrypt(request()->post('password')),
            'role' => 'wali_murid',
            'status' => 'disable'
        ];

        Login::insert($data_login);

        $id_wali_murid = WaliMurid::max('id_wali_murid');

        if($id_wali_murid == null){
            $id_wali_murid = 1;
        } else {
            $id_wali_murid += 1;
        }

        $data = [
            'id_wali_murid' => $id_wali_murid,
            'nama_wali_murid' => request()->post('nama'),
            'id_siswa' => $cek_siswa->id_siswa,
            'alamat' => request()->post('alamat'),
            'id_login' => $data_login['id']
        ];

        WaliMurid::insert($data);

        $url = "/register/verif/".$data_login['id'];
        $isi = [
            'to' => $data_login['e_mail'],
            'url' => $url,
            'text' => 'klik link di bawah ini untuk aktivasi akun'
        ];

        $this->sendVerifikasi($isi);
        return back()->with('message','Berhasil register silahkan tunggu email verifikasi, pastikan email aktif');
    }

    public function sendVerifikasi($data)
    {
        Mail::to($data['to'])->send(new VerificationEmail($data));
    }

    public function activasiAkun($id)
    {
        $activasi = Login::where('id',$id);
        $activasi->update(['status' => 'active']);
        return redirect('/')->with('message','Aktivasi berhasil akun anda telah aktif');;
    }

    public function cekLogin(Request $request)
    {
        $this->validate($request,[
            'email' => 'required',
            'password' => 'required'
        ]);
        
        $email = $request->post('email');
        $password = $request->post('password');
        $id = "";
        $data_session = [];

        $login = Login::where(['e_mail' => $email])->first();

        if($login == null){
            return redirect(url('/'))->with('message','Login gagal email / password salah');
        } else {

            if($login->status == 'disable'){
                return back()->with('message','akun masih non aktif silahkan hubungi admin untuk mengaktifkan');
            }

            if($password == decrypt($login->password)){

                $data_session = [
                    'email' => $login->e_mail,
                    'role' => $login->role,
                    'id' => $login->id,
                ];

                switch ($login->role) {
                    case 'admin':
                        break;
                    case 'guru':
                        $guru = Guru::where('id_login',$login->id)->first();
                        $id = $guru->id_guru_mapel;
                        $nip = $guru->nip;
                        $data_session['nip'] = $nip;
                        $data_session['id_user'] = $id;
                        break;

                    case 'wali_kelas':
                        $wali_kelas = WaliKelas::where('id_login',$login->id)->first();
                        $id = $wali_kelas->id_wali_kelas;
                        $data_session['id_user'] = $id;
                        break;

                    case 'siswa':
                        $siswa = Siswa::where('id_login',$login->id)->first();
                        $id = $siswa->id_siswa;
                        $data_session['id_user'] = $id;
                        break;

                    case 'wali_murid':
                        $wali_murid = WaliMurid::where('id_login',$login->id)->first();
                        $data_session['id_user'] = $wali_murid->id_wali_murid;
                        $data_session['id_siswa'] = $wali_murid->id_siswa;
                        break;
                }
                session($data_session);
                return redirect(url('dashboard'));
            } else {
                return redirect(url('/'))->with('message','Login gagal email / password salah');
            }
        }
    }

    public function addUser()
    {
        $data_user = Login::all();
        $slug = 'adduser';
        return view('page.pengelola_user', compact('data_user','slug'));
    }

    public function saveUser(Request $request)
    {
        $id = Login::max('id');

        if($id == null){
            $id = 1;
        } else {
            $id += 1 ;
        }

        $data = [
            'id' => $id,
            'e_mail' => $request->post('email'),
            'password' => encrypt($request->post('password')),
            'role' => $request->post('role'),
            'status' => 'disable'
        ];

        Login::insert($data);
        return redirect(url('/pengguna'))->with('message','User '.$data['e_mail'].' berhasil di tambahkan');
    }

    public function logout(Request $request)
    {
        $data_session = [
            'email',
            'role'
        ];
        $request->session()->forget($data_session);
        return redirect('/')->with('message','Logout sukses, sampai jumpa kembali... :)');
    }

    public function updateUser(Request $request)
    {
        $id = $request->post('id');

        $data = [
            'e_mail' => $request->post('email'),
            'password' => encrypt($request->post('password')),
            'role' => $request->post('role')
        ];

        Login::where(['id' => $id])->update($data);
        return redirect(url('/pengguna'))->with('message','User '.$data['e_mail'].' berhasil di ubah');
    }

    public function userSetting()
    {
        $login = Login::where('id', session('id'))->first();
        $passdecrypt = decrypt($login->password);
        $slug = "";
        return view('page.user_detil', compact('slug','passdecrypt'));
    }

    public function changePass($id)
    {
        $login = Login::where('id', $id);
        $data = [
            'password' => encrypt(request()->post('password')) 
        ];
        $login->update($data);
        return back()->with('message', 'password berhasil di ubah');
    }
}
