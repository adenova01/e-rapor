<?php

namespace App\Http\Controllers;

use App\Models\Login;
use App\Models\Siswa;
use App\Models\WaliMurid;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class WaliMuridController extends Controller
{
    public function index()
    {
        if(session('role') == 'admin'){
            $wali_murid = WaliMurid::all();
            $siswa = DB::table('tb_wali_murid')->rightJoin('tb_siswa','tb_wali_murid.id_siswa','=','tb_siswa.id_siswa')->where('tb_wali_murid.id_siswa',null)->get();
        }

        $slug = 'walimurid';

        return view('page.wali_murid', compact('wali_murid','slug','siswa'));
    }

    public function show($id)
    {
        $walimurid = WaliMurid::where('id_wali_murid',$id)->first();
        $siswa = DB::table('tb_siswa')->join('tb_jurusan','tb_siswa.jurusan','=','tb_jurusan.id')->where('tb_siswa.id_siswa',$walimurid->id_siswa)->first();

        $slug = 'walimurid';

        // dd($siswa);
        return view('page.detil_wali_murid', compact('walimurid','slug','siswa'));
    }

    public function aktivasi()
    {
        $id_wali_murid = request()->post('wali_murid');
        $wali_murid = WaliMurid::where('id_wali_murid', $id_wali_murid);
        Login::where('id', request()->post('id'))->update(['status' => 'active']);
        $wali_murid->update(['id_login' => request()->post('id')]);

        return back()->with('message','aktivasi sukses');
    }

    public function store()
    {
        $id = WaliMurid::max('id_wali_murid');

        $id == null ? $id = 1 : $id += 1 ;

        $data = [
            'id_wali_murid' => $id,
            'nama_wali_murid' => request()->post('nama'),
            'id_siswa' => request()->post('siswa'),
            'alamat' => request()->post('alamat'),
            'id_login' => null
        ];

        WaliMurid::insert($data);
        return back()->with('message','data berhasil di tambahkan');
    }

    public function update()
    {
        $id = request()->post('id');
        $wali_murid = WaliMurid::where('id_wali_murid', $id);

        $data = [
            'nama_wali_murid' => request()->post('nama'),
            'alamat' => request()->post('alamat'),
            'id_login' => null
        ];

        // dd($wali_murid);
        $wali_murid->update($data);
        return back()->with('message','data berhasil di ubah');
    }
}
