<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Peringkat;
use App\Models\Siswa;
use App\Models\Mapel;
use App\Models\Login;
use App\Models\Guru;
use Illuminate\Support\Facades\DB;

class HomeController extends Controller
{
    public function dashboard()
    {
        // $data_peringkat = Peringkat::all();
        $data_peringkat = DB::table('tb_peringkat')
                    ->join('tb_siswa','tb_siswa.id_siswa','tb_peringkat.id_siswa')
                    ->orderBy('tb_peringkat.rata_rata','desc')
                    ->get();
        $siswa = Siswa::count();
        $mapel = Mapel::count();
        $pengguna = Login::count();
        $guru = Guru::count();
        $slug = 'dashboard';
        return view('page.dashboard', compact('data_peringkat','slug','siswa','mapel','pengguna','guru'));
    }
}
