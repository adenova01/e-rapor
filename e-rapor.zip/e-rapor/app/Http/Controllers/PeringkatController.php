<?php

namespace App\Http\Controllers;

use App\Models\e_rapor;
use App\Models\Peringkat;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class PeringkatController extends Controller
{
    public function index()
    {
        $peringkat = DB::table('tb_peringkat')
                        ->join('tb_siswa','tb_siswa.id_siswa','=','tb_peringkat.id_siswa')
                        ->orderBy('tb_peringkat.rata_rata','desc')
                        ->get();
        
        $slug = "peringkat";
        return view('page.peringkat',compact('peringkat','slug'));
    }

    public static function savePeringkat($id_siswa)
    {
        $nilai = DB::table('tb_nilai')
                    ->selectRaw('avg(nilai) as rata_rata, id_siswa')
                    ->groupBy('id_siswa')
                    ->where('id_siswa',$id_siswa)
                    ->get();

        $id = Peringkat::max('id_peringkat');

        if($id != null){
            $id += 1;
        } else {
            $id = 1;
        }

        $peringkat = Peringkat::where('id_siswa', $id_siswa)->first();
        
        if($peringkat != null){
            $data = [
                'rata_rata' => $nilai[0]->rata_rata
            ];
            Peringkat::where('id_siswa',$id_siswa)->update($data);
        } else {
            $data = [
                'id_peringkat' => $id,
                'id_siswa' => $nilai[0]->id_siswa,
                'rata_rata' => $nilai[0]->rata_rata
            ];
            Peringkat::create($data);
        }

        return $peringkat;
    }
}
