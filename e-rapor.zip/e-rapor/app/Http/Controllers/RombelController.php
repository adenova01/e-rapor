<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Rombel;
use App\Models\Jurusan;
use App\Models\WaliKelas;
use App\Models\Mapel;
use App\Models\Siswa;
use Illuminate\Support\Facades\DB;

class RombelController extends Controller
{
    public function index()
    {
        // $rombel = Rombel::all();
        $rombel = DB::table('tb_rombel')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_rombel.id_jurusan')
                    ->get();
                    
        $jurusan = Jurusan::all();
        $wali_kelas = WaliKelas::all();
        $mapel = Mapel::all();
        $slug = 'rombel';
        return view('page.rombel', compact('rombel','jurusan','slug','wali_kelas','mapel'));
    }

    public function store(Request $request)
    {
        $id = Rombel::max('id');

        if($id == null){
            $id = 1;
        } else {
            $id += 1;
        }

        $data = [
            'id' => $id,
            'kode_rombel' => $request->post('kode_rombel'),
            'nama_rombel' => request()->post('nama_rombel'),
            'id_jurusan' => $request->post('jurusan'),
            'kelas' => $request->post('kelas'),
            'id_mapel' => implode(',', $request->post('mapel')),
            'tahun_ajar' => $request->post('tahun_ajar'),
            'semester' => $request->post('semester')
        ];

        Rombel::create($data);
        return back()->with('message','data berhasil di tambahkan');
    }

    public function update()
    {
        $rombel = Rombel::find(request()->post('id_rombel'));
        
        $data = [
            'kode_rombel' => request()->post('kode_rombel'),
            'nama_rombel' => request()->post('nama_rombel'),
            'id_jurusan' => request()->post('jurusan'),
            'kelas' => request()->post('kelas'),
            'id_mapel' => implode(',', request()->post('mapel')),
            'tahun_ajar' => request()->post('tahun_ajar'),
            'semester' => request()->post('semester')
        ];

        // dd($data);
        $rombel->update($data);
        return back()->with('message','data berhasil di ubah');
    }

    public function detilRombel($id)
    {
        $rombel = DB::table('tb_rombel')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_rombel.id_jurusan')
                    ->where('tb_rombel.id',$id)
                    ->first();
        
        $rombel_mapel = Rombel::find($id);

        $array_mapel = explode(',',$rombel_mapel->id_mapel);
        $data_mapel = [];
        
        for($i=0; $i<count($array_mapel); $i++){
            $mapel = Mapel::where('id', $array_mapel[$i])->first();
            $data_mapel[0][$i] = $mapel->nama_mapel;
            $data_mapel[1][$i] = $mapel->kode_mapel;
        }

        $siswa = Siswa::where('rombel_id',$id)->get();
        $jumlah_siswa = $siswa->count();

        $slug = 'rombel';
        return view('page.detil_rombel', compact('slug','rombel','jumlah_siswa','data_mapel','siswa'));
    }
}
