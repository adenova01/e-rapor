<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Guru;
use App\Models\Mapel;
use App\Models\Login;

class GuruController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $mapel_pengampu = Guru::all();
        $mapel_arry = [];
        
        for ($i=0; $i < count($mapel_pengampu); $i++) { 
            $arry_kode_mapel[$i] = explode(',',$mapel_pengampu[$i]->pengampu_mapel);
            for($a=0; $a<count($arry_kode_mapel[$i]); $a++){
                $kode = $arry_kode_mapel[$i][$a];
                $mapel_arry[$i][$a] = Mapel::where('id',$kode)->first();
            }
        }

        // dd($mapel_arry);
        $guru = Guru::all();
        $mapel = Mapel::all();
        $slug = "guru";
        return view('page.guru', compact('guru','slug','mapel','mapel_arry'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function aktivasi(Request $request)
    {
        $guru = Guru::where('id_guru_mapel', $request->post('guru'));

        if($guru->update(['id_login' => $request->post('id')])){
            Login::where('id',$request->post('id'))->update(['status' => 'active']);
            return back()->with('message','aktivasi sukses');
        } else {
            return back()->with('message','aktivasi gagal');
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = Guru::max('id_guru_mapel');

        if($id != null){
            $id += 1;
        } else {
            $id = 1;
        }

        $data = [
            'nip' => $request->post('nip'),
            'id_guru_mapel' => $id,
            'nama_guru_mapel' => $request->post('nama'),
            'pengampu_mapel' => implode(',',$request->post('mapel')),
            'alamat' => $request->post('alamat')
        ];

        Guru::create($data);

        return back()->with('message','data guru berhasil di tambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $guru = Guru::where('id_guru_mapel',$request->post('id'));

        $data = [
            'nip' => $request->post('nip'),
            'nama_guru_mapel' => $request->post('nama'),
            'pengampu_mapel' => implode(',',$request->post('mapel')),
            'alamat' => $request->post('alamat')
        ];

        $guru->update($data);
        return back()->with('message','data guru berhasil di tambahkan');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
