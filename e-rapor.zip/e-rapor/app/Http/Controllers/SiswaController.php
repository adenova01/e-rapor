<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Siswa;
use App\Models\Mapel;
use App\Models\Login;
use App\Models\Jurusan;
use App\Models\Rombel;
use App\Models\WaliKelas;
use Illuminate\Support\Facades\DB;

class SiswaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(session('role') == 'siswa'){
            $siswa = DB::table('tb_siswa')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_siswa.jurusan')
                    ->where('tb_siswa.id_siswa',session('id_user'))
                    ->get();
        } else if(session('role') == 'wali_murid'){
            $siswa = DB::table('tb_siswa')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_siswa.jurusan')
                    ->where('tb_siswa.id_siswa',session('id_siswa'))
                    ->get();

        } else if(session('role') == 'wali_kelas') {
            $wali_kelas = WaliKelas::where('id_wali_kelas',session('id_user'))->first();
            $siswa = DB::table('tb_siswa')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_siswa.jurusan')
                    ->where('tb_siswa.kelas',$wali_kelas->pengampu_kelas)
                    ->where('tb_siswa.jurusan',$wali_kelas->pengampu_jurusan)
                    ->get();
        } else {
            $siswa = DB::table('tb_siswa')
                    ->join('tb_jurusan','tb_jurusan.id','=','tb_siswa.jurusan')
                    ->get();
        }

        $jurusan = Jurusan::all();
        $mapel = Mapel::all();
        $rombel = Rombel::all();
        $slug = 'siswa';

        // dd($mapel_detil[1][0]->nama_mapel);
        return view('page.siswa', compact('siswa','slug','mapel','jurusan','rombel'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function aktivasi()
    {
        $siswa = Siswa::where('id_siswa', request()->post('siswa'));
        
        if($siswa->update(['id_login' => request()->post('id')])){
            $login = Login::where('id', request()->post('id'));
            $login->update(['status' => 'active']);
            return back()->with('message','aktivasi sukses');
        } else {
            return back()->with('message','aktivasi gagal');
        }

    }

    public function addRombel()
    {
        $siswa = Siswa::where('id_siswa',request()->post('id_siswa'));
        $siswa->update(['rombel_id' => request()->post('rombel')]);
        return back()->with('message','rombel berhasil di tambahkan');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            'nis' => 'required',
            'Nama' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'alamat' => 'required'
        ]);

        $id = Siswa::max('id_siswa');

        if($id == null){
            $id = 1;
        } else {
            $id += 1;
        }

        $data = [
            'nis' => $request->post('nis'),
            'id_siswa' => $id,
            'nama_siswa' => $request->post('Nama'),
            'kelas' => $request->post('kelas'),
            'jurusan' => $request->post('jurusan'),
            'alamat' => $request->post('alamat'),
        ];

        Siswa::create($data);
        return redirect('/siswa')->with('message','siswa berhasil di tambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $request->validate([
            'nis' => 'required',
            'Nama' => 'required',
            'kelas' => 'required',
            'jurusan' => 'required',
            'alamat' => 'required'
        ]);

        $siswa = Siswa::where(['id_siswa' => $request->post('id')]);

        $data = [
            'nis' => $request->post('nis'),
            'nama_siswa' => $request->post('Nama'),
            'kelas' => $request->post('kelas'),
            'jurusan' => $request->post('jurusan'),
            'alamat' => $request->post('alamat'),
        ];

        // dd($data);
        $siswa->update($data);
        return redirect('/siswa')->with('message','siswa berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
