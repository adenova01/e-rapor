<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Jurusan;

class JurusanController extends Controller
{
    public function index()
    {
        $jurusan = Jurusan::all();
        $slug = 'jurusan';
        return view('page.jurusan',compact('jurusan','slug'));
    }

    public function store(Request $request)
    {
        $id = Jurusan::max('id');

        if($id == null){
            $id = 1;
        } else {
            $id += 1;
        }

        $data = [
            'id' => $id,
            'kode_jurusan' => $request->post('kode_jurusan'),
            'nama_jurusan' => $request->post('nama_jurusan')
        ];

        Jurusan::create($data);

        return back()->with('message','data jurusan berhasil di tambahkan');
    }

    public function update()
    {
        $jurusan = Jurusan::where('id',request()->post('id'));

        $data = [
            'kode_jurusan' => request()->post('kode_jurusan'),
            'nama_jurusan' => request()->post('jurusan')
        ];

        $jurusan->update($data);

        return back()->with('message','data berhasil di ubah');
    }
}
