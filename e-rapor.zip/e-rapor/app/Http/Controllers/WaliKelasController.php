<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\WaliKelas;
use App\Models\Guru;
use App\Models\Login;
use App\Models\Jurusan;
use Illuminate\Support\Facades\DB;

class WaliKelasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $walikelas = DB::table('tb_wali_kelas')
                        ->join('tb_guru_mapel','tb_wali_kelas.nip','=','tb_guru_mapel.nip')
                        ->join('tb_jurusan','tb_wali_kelas.pengampu_jurusan','=','tb_jurusan.id')
                        ->get();

        $jurusan = Jurusan::all();
        $guru = Guru::all();
        $slug = "wali_kelas";
        return view('page.wali_kelas', compact('slug','guru','walikelas','jurusan'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function aktivasi()
    {
        $walikelas = WaliKelas::where('id_wali_kelas', request()->post('wali_kelas'));

        if($walikelas->update(['id_login' => request()->post('id')])){
            $login = Login::where('id',request()->post('id'));
            $login->update(['status' => 'active']);
            return back()->with('message','aktivasi sukses');
        } else {
            return back()->with('message','aktivasi gagal');
        }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $id = WaliKelas::max('id_wali_kelas');

        if($id != null){
            $id += 1;
        } else {
            $id = 1;
        }

        $data = [
            'nip' => $request->post('nip'),
            'id_wali_kelas' => $id,
            'pengampu_kelas' => $request->post('kelas'),
            'pengampu_jurusan' => $request->post('jurusan'),
        ];

        // dd($data);

        WaliKelas::create($data);

        return back()->with('message','data berhasil di tambahkan');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request)
    {
        $data_guru = Guru::where('nip',$request->post('nip'))->first();

        $data = [
            'nip' => $request->post('nip'),
            'pengampu_kelas' => $request->post('kelas'),
            'pengampu_jurusan' => $request->post('jurusan'),
        ];

        WaliKelas::where('id_wali_kelas',$request->post('id_wali_kelas'))->update($data);

        return back()->with('message','data berhasil di ubah');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
