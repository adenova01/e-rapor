<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

class Pengaman
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle(Request $request, Closure $next)
    {
        if(empty(session()->has('role'))){
            return redirect('/')->with('message','akses danied');
        }
        return $next($request);
    }
}
