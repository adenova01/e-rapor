<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">

                {{-- =================================================================== --}}

                {{-- role admin --}}
                @if (session('role') == 'admin')
                    
                    <li class="{{ $slug == 'dashboard' ? 'active' : '' }}">
                        <a href="{{ url('/dashboard') }}"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    
                    <li class="{{ $slug == 'guru' ? 'active' : '' }}">
                        <a href="{{ url('/guru') }}"><i class="menu-icon fa fa-users"></i>Guru</a>
                    </li>

                    <li class="{{ $slug == 'wali_kelas' ? 'active' : '' }}">
                        <a href="{{ url('/waliKelas') }}"><i class="menu-icon fa fa-users"></i>Wali Kelas</a>
                    </li>
                    
                    <li class="{{ $slug == 'mapel' ? 'active' : '' }}">
                        <a href="{{ url('/mapel') }}"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>
                        
                    <li class="{{ $slug == 'rombel' ? 'active' : '' }}">
                        <a href="{{ url('/rombel') }}"><i class="menu-icon fa fa-users"></i>Rombel</a>
                    </li>
                    
                    <li class="{{ $slug == 'rapor' ? 'active' : '' }}">
                        <a href="{{ url('/rapor') }}"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="{{ $slug == 'nilai' ? 'active' : '' }}">
                        <a href="{{ url('nilai') }}"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="{{ $slug == 'peringkat' ? 'active' : '' }}">
                        <a href="{{url('/peringkat')}}"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="{{ $slug == 'siswa' ? 'active' : '' }}">
                        <a href="{{ url('/siswa') }}"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                    
                    <li class="{{ $slug == 'jurusan' ? 'active' : '' }}">
                        <a href="{{ url('/jurusan') }}"><i class="menu-icon fa fa-th-list"></i>Jurusan</a>
                    </li>
                    
                    
                    <li class="{{ $slug == 'walimurid' ? 'active' : '' }}">
                        <a href="/wali_murid"> <i class="menu-icon fa fa-user"></i>Wali Murid</a>
                    </li>
                    
                    
                    <li class="menu-title">Extras</li><!-- /.menu-title -->
                    
                    <li class="{{ $slug == 'adduser' ? 'active' : '' }}">
                        <a href="{{ url('/pengguna') }}"><i class="menu-icon fa fa-user-circle-o" aria-hidden="true"></i>User Pengguna</a>
                    </li>
                    
                @endif
                {{-- end admin --}}

                {{-- =================================================================== --}}

                {{-- role guru --}}
                @if (session('role') == 'guru')
                    <li class="{{ $slug == 'dashboard' ? 'active' : '' }}">
                        <a href="{{ url('/dashboard') }}"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    
                    <li class="{{ $slug == 'guru' ? 'active' : '' }}">
                        <a href="{{ url('/guru') }}"><i class="menu-icon fa fa-users"></i>Guru</a>
                    </li>

                    <li class="{{ $slug == 'mapel' ? 'active' : '' }}">
                        <a href="{{ url('/mapel') }}"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>

                    <li class="{{ $slug == 'nilai' ? 'active' : '' }}">
                        <a href="{{ url('nilai') }}"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>

                    <li class="{{ $slug == 'peringkat' ? 'active' : '' }}">
                        <a href="{{url('/peringkat')}}"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>
                @endif
                {{-- end guru --}}

                {{-- =================================================================== --}}

                {{-- role wali_kelas --}}
                @if (session('role') == 'wali_kelas')
                    <li class="{{ $slug == 'dashboard' ? 'active' : '' }}">
                        <a href="{{ url('/dashboard') }}"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>

                    <li class="{{ $slug == 'wali_kelas' ? 'active' : '' }}">
                        <a href="{{ url('/waliKelas') }}"><i class="menu-icon fa fa-users"></i>Wali Kelas</a>
                    </li>

                    <li class="{{ $slug == 'mapel' ? 'active' : '' }}">
                        <a href="{{ url('/mapel') }}"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>

                    <li class="{{ $slug == 'rombel' ? 'active' : '' }}">
                        <a href="{{ url('/rombel') }}"><i class="menu-icon fa fa-users"></i>Rombel</a>
                    </li>

                    <li class="{{ $slug == 'rapor' ? 'active' : '' }}">
                        <a href="{{ url('/rapor') }}"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="{{ $slug == 'nilai' ? 'active' : '' }}">
                        <a href="{{ url('nilai') }}"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="{{ $slug == 'peringkat' ? 'active' : '' }}">
                        <a href="{{url('/peringkat')}}"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="{{ $slug == 'siswa' ? 'active' : '' }}">
                        <a href="{{ url('/siswa') }}"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                @endif
                {{-- end wali_kelas --}}

                {{-- =================================================================== --}}

                {{-- role siswa / wali murid --}}
                @if (session('role') == 'siswa' || session('role') == 'wali_murid')
                    <li class="{{ $slug == 'dashboard' ? 'active' : '' }}">
                        <a href="{{ url('/dashboard') }}"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>

                    <li class="{{ $slug == 'rapor' ? 'active' : '' }}">
                        <a href="{{ url('/rapor') }}"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="{{ $slug == 'nilai' ? 'active' : '' }}">
                        <a href="{{ url('nilai') }}"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="">
                        <a href="{{url('/peringkat')}}"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="{{ $slug == 'siswa' ? 'active' : '' }}">
                        <a href="{{ url('/siswa') }}"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                @endif
                {{-- end siswa / wali murid--}}
                
                <li class="">
                    <a href="{{ url('logout') }}"> <i class="menu-icon fa fa-sign-out"></i>Logout</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>
