<!doctype html>
<html class="no-js" lang="">
<head>
    @include('template.head')
</head>

<body>
    <!-- Left Panel -->
    @include('template.sidebar')
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        @include('template.top_nav')
        <!-- /#header -->
        <!-- Content -->
        <div class="content" id="app">
            @yield('content')
        </div>
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        @include('template.footer')
        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="{{ url('/assets/js/main.js') }}"></script>

    
    {{-- Data Tables --}}
    <script src="{{ url('') }}/assets/js/lib/data-table/datatables.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/jszip.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="{{ url('') }}/assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="{{ url('') }}/assets/js/init/datatables-init.js"></script>
    {{-- select 2 --}}
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    {{-- sweet alert --}}
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    @include('library.vue')

    <script type="text/javascript">
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
            $('.js-example-basic-multiple').select2();
            $('#myTable').DataTable();

            $("#show_hide_password a").on('click', function(event) {
                event.preventDefault();
                if($('#show_hide_password input').attr("type") == "text"){
                    $('#show_hide_password input').attr('type', 'password');
                    $('#show_hide_password i').addClass( "fa-eye-slash" );
                    $('#show_hide_password i').removeClass( "fa-eye" );
                }else if($('#show_hide_password input').attr("type") == "password"){
                    $('#show_hide_password input').attr('type', 'text');
                    $('#show_hide_password i').removeClass( "fa-eye-slash" );
                    $('#show_hide_password i').addClass( "fa-eye" );
                }
            });
        });
    </script>
</body>
</html>
