<header id="header" class="header">
    <div class="top-left">
        <div class="navbar-header">
            <a class="navbar-brand" href="javascript:void(0)"><img src="{{ url('images/logo.png') }}" alt="Logo"></a>
            <a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
        </div>
    </div>
    <div class="top-right">
        <div class="header-menu">
            <div class="header-left">
                <div class="dropdown for-notification">
                    <button class="btn btn-info dropdown-toggle" type="button" id="notification" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <span class="fa fa-user-circle-o" style="font-size: 20pt; margin-top:15px; margin-right: -9px"></span>
                    </button>
                    <span data-toggle="dropdown" style="cursor:pointer" aria-haspopup="true" aria-expanded="false">{{session('email')}}</span>
                    <div class="dropdown-menu bg-secondary" aria-labelledby="notification">
                        <a class="dropdown-item media" href="{{ url('userSetting') }}">
                            <i class="fa fa-cogs text-light"></i>
                            <p class="text-light">Setting</p>
                        </a>
                        <a class="dropdown-item media" href="{{ url('/logout') }}">
                            <i class="fa fa-sign-out text-light"></i>
                            <p class="text-light">Logout</p>
                        </a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</header>
