<p>{{$data['text']}}</p>
<p><a href="{{url($data['url'])}}">Aktivasi</a></p>