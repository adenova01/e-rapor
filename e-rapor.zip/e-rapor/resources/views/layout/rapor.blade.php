<!DOCTYPE html>
<html>
    <head>
        <title>Rapor {{$siswa->nama_siswa}}</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <style>
            body {
                font: 12pt "Times New Roman";
            }

            .cover {
                margin: 0;
                padding: 0;
                border: 1.5px solid black;
            }

            .page_break {
                page-break-after: always;
            }

            .isi-rapor {
                padding: 10px;
            }

            .tbl tr th{
                border: 1px solid black;
            }

            .tbl tr td{
                border:1px solid black;
            }

            .ttd {
                width: 30%;
                margin-left: 65%;
                margin-top: 15%;
            }
        </style>
    </head>
    <body>
        <div class="cover">
            <div class="row">
                <div class="col-sm-4">
                <img src="https://s.sim.siap-online.com//upload/sekolah/30200792.150130103154.png" class="img" style="margin-top: 70px;margin-left: 110%; margin-bottom: 70px">
            </div>
            </div>
            <div class="row" style="margin-bottom: 120px">
                <div class="col-sm-12">
                    <h2 class="text-center">RAPOR</h2>
                    <h2 class="text-center">SEKOLAH MENENGAH ATAS</h2>
                    <h2 class="text-center">SMAN 1 IKARAU KUALA</h2>
                </div>
            </div>
            <div class="row" style="margin-bottom: 60px">
                <div class="col-12">
                    <h3 class="text-center">Nama Peserta Didik</h3>
                    <h4 class="text-center text-info">{{$siswa->nama_siswa}}</h4>
                </div>
            </div>
            <div class="row" style="margin-bottom: 21.1%">
                <div class="col-12">
                    <h3 class="text-center">NISN</h3>
                    <h4 class="text-center text-info">{{$siswa->nis}}</h4>
                </div>
            </div>
        </div>
        
        <div class="page_break"></div>

        <div class="isi-rapor">
            <div class="row">
                <table width="100%" style="border-bottom: 1px solid black;">
                    <tbody>
                        <tr>
                            <td>Nama Sekolah</td>
                            <td> : </td>
                            <td>SMAN 1 IKARAU KUALA</td>
                            <td>Kelas</td>
                            <td>:</td>
                            <td>{{$siswa->kelas}} ( 
                                {{$siswa->kelas == 'X' ? 'Sepuluh' : 
                                    ($siswa->kelas == 'XI' ? 'Sebelas' : 
                                        ($siswa->kelas == 'XII' ? 'Dua belas' : '')
                                    )}} )
                            </td>
                        </tr>
                        <tr>
                            <td>Alamat</td>
                            <td> : </td>
                            <td>Bangkuang, Karau Kuala</td>
                            <td>Semester</td>
                            <td>:</td>
                            <td>{{$siswa->semester}}</td>
                        </tr>
                        <tr>
                            <td>Nama Peserta Didik</td>
                            <td> : </td>
                            <td>{{$siswa->nama_siswa}}</td>
                            <td>Tahun Pelajaran</td>
                            <td>:</td>
                            <td>{{$siswa->tahun_ajar}}</td>
                        </tr>
                        <tr>
                            <td>Nomor Induk / NISN</td>
                            <td> : </td>
                            <td colspan="4">{{$siswa->nis}}</td>
                        </tr>
                        <tr><td colspan="6"><br></td></tr>
                    </tbody>
                </table>
            </div>
            <div class="row">
                <div class="col-12 mt-3 p-0 mb-2">
                    <table width="100%">
                        <tbody>
                            <tr>
                                <th>PENGETAHUAN DAN KETERAMPILAN</th>
                            </tr>
                            <tr>
                                <th>Kriteria Ketuntasan Minimal = {{$nilai_ketuntasan}}</th>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="row">
                <div class="col-12 p-0">
                    <table class="tbl" width="100%">
                        <thead class="text-center">
                            <tr>
                                <th rowspan="2" style="vertical-align: middle;" width="25px">No</th>
                                <th rowspan="2" style="vertical-align: middle;">Mata Pelajaran</th>
                                <th colspan="3">Pengetahuan</th>
                            </tr>
                            <tr>
                                <th width="35px">Nilai</th>
                                <th width="65px">Predikat</th>
                                <th>Catatan</th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <tr>
                                <th colspan="5" class="text-left">Kelompok A</th>
                            </tr>
                            @foreach ($data_rapor as $i => $item)
                                @if ($item->kategori == 'A')
                                    <tr>
                                        <td>{{$i+1}}</td>
                                        <td>{{$item->nama_mapel}}</td>
                                        <td>{{$item->nilai}}</td>
                                        <td>{{$item->predikat}}</td>
                                        <td>{{$item->deskripsi}}</td>
                                    </tr>
                                @endif
                            @endforeach
                            <tr>
                                <th colspan="5" class="text-left">Kelompok B</th>
                            </tr>
                            @foreach ($data_rapor as $a => $item)
                                @if ($item->kategori == 'B')
                                    <tr>
                                        <td>{{$a + 1}}</td>
                                        <td>{{$item->nama_mapel}}</td>
                                        <td>{{$item->nilai}}</td>
                                        <td>{{$item->predikat}}</td>
                                        <td>{{$item->deskripsi}}</td>
                                    </tr>
                                @endif
                            @endforeach
                        </tbody>
                    </table>

                    <div class="ttd">
                        <table>
                            <tr>
                                <td>Bangkuang, {{$tglnya}}</td>
                            </tr>
                            <tr>
                                <td>Wali Kelas,</td>
                            </tr>
                            <tr>
                                <td>
                                    <div style="border-bottom: 2px solid black; margin-top:50px">
                                        <strong>{{strtoupper($walas->nama_guru_mapel)}}</strong>
                                    </div>
                                    <span>Nip. {{$walas->nip}}</span>
                                </td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </body>
</html>