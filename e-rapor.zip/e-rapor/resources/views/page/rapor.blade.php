@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Rapor</strong>
                </div>
                <div class="card-body">
                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>NIS</th>
                                <th>Nama Siswa</th>
                                <th>Alamat</th>
                                @if (session('role') == 'wali_kelas' || session('role') == 'wali_murid' || session('role') == 'siswa')
                                    <th>Rapor</th>
                                @endif
                                <th>Status Rapor</th>
                                @if (session('role') == 'wali_kelas' || session('role') == 'admin' || session('role') == 'guru')
                                <th>Opsi</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @if ($siswa_rapor != null)
                            @foreach ($siswa_rapor as $i => $item)
                                <tr>
                                    <td>{{$item->nis}}</td>
                                    <td>{{$item->nama_siswa}}</td>
                                    <td>{{$item->alamat}}</td>
                                    @if (session('role') == 'wali_kelas')
                                    <td class="text-center">
                                        @foreach($status_rapor as $row)
                                            @if ($row->id_siswa == $item->id_siswa)
                                            <a href="{{ url('rapor/lihat'.'/'.$item->id_siswa) }}" target="_blank" class="text-danger"><i class="fa fa-file-pdf-o" style="font-size: 50pt"></i></a>
                                            <p>{{$item->nis.'_'.$item->nama_siswa}}.pdf</p>
                                            @endif
                                        @endforeach
                                    </td>
                                    @endif

                                    <td>
                                        @if (count($siswa_rapor) == 0)
                                            <span class="badge badge-warning">Belum Ada Rapor</span>
                                        @endif
                                        @if(count($status_rapor) != 0)
                                            @foreach ($status_rapor as $i => $row)
                                                @if($item->id_siswa == $row->id_siswa)
                                                    <span class="badge badge-{{$row->status == 'selesai' ? 'success' : 'info'}}">{{$row->status}}</span>
                                                @endif
                                            @endforeach
                                        @endif
                                    </td>
                                    <td>
                                        <button v-on:click="getNilaiSiswa({{$item->id_siswa}})" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#modalNilai"><i class="fa fa-eye"></i> Lihat Nilai</button>
                                        
                                        @if(session('role') == 'wali_kelas')
                                            <a href="{{ url('/rapor/isi_nilai/'.$item->id_siswa) }}" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i> Isi Rapor</a>    
                                        @endif

                                        @if(count($status_rapor) != 0)
                                            @foreach ($status_rapor as $row)

                                                @if ($row->id_siswa == $item->id_siswa && $row->status == 'selesai')
                                                    <a href="{{ url('rapor/download'.'/'.$item->id_siswa) }}" class="btn btn-outline-primary btn-sm"><i class="fa fa-download"></i> Download Rapor</a>
                                                @endif

                                                @if ($item->id_siswa == $row->id_siswa && $row->status != 'selesai' && session('role') == 'wali_kelas')
                                                    <button v-on:click="updateRaporStatus({{$item->id_siswa}})" class="btn btn-outline-success btn-sm"><i class="fa fa-check"></i> Selesai</button>
                                                @endif
                                            @endforeach
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                            @endif
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal liat nilai --}}

    <div class="modal fade" id="modalNilai" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Detil Nilai</div>
                    <div class="card-body card-block">
                        <table class="table table-striped">
                            <thead class="bg-dark text-light">
                                <tr>
                                    <td>Nama Mapel</td>
                                    <td>Nilai</td>
                                    <td>Huruf</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="nilai in data_nilai">
                                    <td>@{{nilai.nama_mapel}}</td>
                                    <td>@{{nilai.nilai}}</td>
                                    <td>@{{nilai.nilai_huruf}}</td>
                                </tr>
                                <tr class="bg-dark text-light">
                                    <th>Rata-rata</th>
                                    <th>@{{nilai_rata}}</th>
                                    <th>@{{nilai_rata_huruf}}</th>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-actions form-group">
                            <button type="button" class="btn btn-secondary btn-sm text-right" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection