@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Wali Murid</strong>
                </div>
                <div class="card-body">

                    @if (session('role') == 'admin')
                        <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Wali Murid</button>
                    @endif

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Nama wali</th>
                                {{-- <th>Nama Siswa</th> --}}
                                <th>Alamat</th>
                                {{-- <th>Email</th> --}}
                                @if (session('role') == 'admin')
                                <th>Opsi</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($wali_murid as $item)
                                <tr>
                                    <td>{{$item->nama_wali_murid}}</td>
                                    {{-- <td>{{$item->nama_siswa == null ? 'null' : $item->nama_siswa}}</td> --}}
                                    <td>{{$item->alamat}}</td>
                                    {{-- <td>{{$item->e_mail == null ? 'null' : $item->e_mail}}</td> --}}
                                    @if (session('role') == 'admin')
                                    <td>
                                        <a href="/wali_murid/detil/{{$item->id_wali_murid}}" class="btn btn-outline-info btn-sm"><i class="fa fa-edit"></i> Detil</a>
                                        <button v-on:click="editWali_murid({{$item->id_wali_murid}})" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="deleteWaliMurid({{$item->id_wali_murid}},'{{$item->nama_wali_murid}}')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Wali Murid</div>
                    <div class="card-body card-block">
                        <form action="{{ url('/wali_murid/save') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="text" id="nama" name="nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Siswa..." data-width="100%" name="siswa" class="js-example-basic-single" required>
                                        @foreach ($siswa as $item)
                                            <option value="" label="default"></option>
                                            <option value="{{$item->id_siswa}}">{{$item->nama_siswa}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}

    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Wali Kelas</div>
                    <div class="card-body card-block">
                        <form action="{{ url('/wali_murid/update') }}" method="post" class="">
                            @csrf
                            <input type="hidden" name="id" v-model="id_user"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_wali_murid" type="text" id="nama" name="nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            {{-- <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Siswa..." data-width="100%" name="siswa" class="js-example-basic-single" required>
                                        @foreach ($siswa as $item)
                                            <option value="" label="default"></option>
                                            <option value="{{$item->id_siswa}}">{{$item->nama_siswa}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div> --}}
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea v-model="alamat_wali_murid" type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}
@endsection