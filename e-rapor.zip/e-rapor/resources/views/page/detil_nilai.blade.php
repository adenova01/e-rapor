@extends('template.master')
@section('content')
<div class="row">
    <div class="col-sm-12">
        
        @if (session('message'))
            <div class="alert alert-info text-center">{{session('message')}}</div>
        @endif
        <div class="card">
            <div class="card-header">
                <strong class="card-title">{{$nama_siswa->nis}} - {{$nama_siswa->nama_siswa}}</strong>
                <a href="{{ url('/nilai') }}" class="btn btn-primary btn-sm" style="float:right; margin-right: 15px"><span class="fa fa-arrow-left"></span> back</a>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Nama Mapel</th>
                            <th>Nama Nilai</th>
                            <th>Nilai</th>
                            <th>Nilai Huruf</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($detil_nilai as $item)
                            <tr>
                                <td>{{$item->nama_mapel}}</td>
                                <td>{{$item->nama_nilai}}</td>
                                <td>{{$item->nilai}}</td>
                                <td>{{$item->nilai_huruf}}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection