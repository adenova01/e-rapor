@extends('template.master')
@section('content')
<div class="row">
    <div class="col-sm-12">
        
        @if (session('message'))
            <div class="alert alert-info text-center">{{session('message')}}</div>
        @endif
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Data Nilai</strong>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>Kode Rombel</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach ($siswa_rombel as $item)    
                            <tr>
                                <td>{{$item->nis}}</td>
                                <td>{{$item->nama_siswa}}</td>
                                <td>{{$item->kelas}}</td>
                                <td>{{$item->nama_jurusan}}</td>
                                <td>{{$item->kode_rombel}}</td>
                                <td>
                                    @if (session('role') == 'guru')
                                        <a href="{{ url('/isiNilai'.'/'.$item->id_siswa) }}" class="btn btn-outline-primary btn-sm m-2"><i class="fa fa-pencil"></i> Detil</a>
                                    @endif
                                    <a href="{{ url('/detilNilai'.'/'.$item->id_siswa) }}" class="btn btn-outline-success btn-sm m-2"><i class="fa fa-eye"></i> Nilai</a>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection