@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">

            <div class="container">
                <div class="row gutters">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="account-settings">
                                    <div class="user-profile">
                                        <div class="user-avatar">
                                            <img src="{{ url('storage/avatar/default.jpg') }}" alt="Maxwell Admin">
                                        </div>
                                        <h5 class="user-name">{{session('role')}}</h5>
                                        <h6 class="user-email">{{session('email')}}</h6>
                                    </div>
                                    <div class="about">
                                        {{-- <h5>About</h5>
                                        <p>I'm Yuki. Full Stack Designer I enjoy creating user-centric, delightful and human experiences.</p> --}}
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                        <div class="card h-100">
                            <div class="card-body">
                                @if (session('message'))
                                    <div class="alert alert-info">{{session('message')}}</div>
                                @endif
                                <form action="/changePass/{{session('id')}}" method="post">
                                @csrf
                                <div class="row gutters">
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="form-group">
                                            <label for="fullName">Email</label>
                                            <input type="email" readonly class="form-control" id="fullName" placeholder="Enter full name" value="{{session('email')}}">
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <div class="input-group" id="show_hide_password">
                                              <input class="form-control" name="password" type="password" value="{{$passdecrypt}}">
                                              <div class="input-group-addon">
                                                <a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row gutters">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection