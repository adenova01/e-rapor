@extends('template.master')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Detil Wali Murid</strong>
                <a href="{{url('/wali_murid')}}" class="btn btn-primary btn-sm" style="float:right; margin-right: 15px"><span class="fa fa-arrow-left"></span> back</a>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="col-2">Nama Wali Murid</th>
                            <td class="col-1">:</td>
                            <td>{{$walimurid->nama_wali_murid}}</td>
                        </tr>
                        <tr>
                            <th>Nama Siswa</th>
                            <td>:</td>
                            <td>{{$siswa->nama_siswa}}</td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>:</td>
                            <td>{{$siswa->kelas}}</td>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <td>:</td>
                            <td>{{$siswa->nama_jurusan}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    {{-- <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Mapel</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Kode Mapel</th>
                                    <th>Nama Mapel</th>
                                </tr>
                            </thead>
                            <tbody>
                                @for($i=0; $i<count($data_mapel[0]); $i++)
                                <tr>
                                    <td>{{$data_mapel[1][$i]}}</td>
                                    <td>{{$data_mapel[0][$i]}}</td>
                                </tr>
                                @endfor
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Siswa</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($siswa as $item)
                                <tr>
                                    <td>{{$item->nis}}</td>
                                    <td>{{$item->nama_siswa}}</td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div> --}}
</div>
    
@endsection