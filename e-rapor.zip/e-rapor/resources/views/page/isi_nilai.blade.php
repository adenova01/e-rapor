@extends('template.master')
@section('content')
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Detil Siswa</strong>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="col-2">NIS</th>
                            <td class="col-1">:</td>
                            <td>{{$detil_siswa->nis}}</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Nama</th>
                            <td>:</td>
                            <td>{{$detil_siswa->nama_siswa}}</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>:</td>
                            <td>{{$detil_siswa->kelas}}</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <td>:</td>
                            <td>{{$detil_siswa->nama_jurusan}}</td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Semester</th>
                            <td>:</td>
                            <td>{{$detil_siswa->semester}}</td>
                            <th>Tahun Ajar</th>
                            <td>{{$detil_siswa->tahun_ajar}}</td>
                        </tr>
                        <tr>
                            <th>Kode Rombel</th>
                            <td>:</td>
                            <td><span class="badge badge-info">{{$detil_siswa->kode_rombel}}</span></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Mapel</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Kode Mapel</th>
                                    <th>Nama Mapel</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if ($detil_mapel[0] != null)
                                    @for($i=0; $i<count($detil_mapel); $i++)
                                    <tr>
                                        <td>{{$detil_mapel[$i]->kode_mapel}}</td>
                                        <td>{{$detil_mapel[$i]->nama_mapel}}</td>
                                        <td>
                                            <button v-on:click="getDetilMapel({{$detil_mapel[$i]->id}})" data-toggle="modal" data-target="#mediumModal" class="btn btn-info btn-sm"><span class="fa fa-pencil"></span> Isi Nilai</button>
                                            
                                            <button v-on:click="getDetilNilaiSiswa({{$detil_mapel[$i]->id}}, {{$detil_siswa->id_siswa}})" data-toggle="modal" data-target="#editModal" class="btn btn-secondary btn-sm"><span class="fa fa-edit"></span> Edit Nilai</button>
                                            
                                        </td>
                                    </tr>
                                    @endfor
                                @else 
                                    <tr>
                                        <td class="text-center" colspan="3">Tidak Ada Mapel Yang di Ampu</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

{{-- modal isi nilai --}}
<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Nilai</h5>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Mapel</th>
                                <th colspan="2">: @{{kode_mapel_detil}}</th>
                            </tr>
                            <tr>
                                <th>Nama Mapel</th>
                                <th colspan="2">: @{{nama_mapel_detil}}</th>
                            </tr>
                            <tr class="text-center">
                                <th class="text-left">Nama Nilai</th>
                                <th class="text-center">Nilai Angka</th>
                                <th class="text-right">Nilai Huruf</th>
                            </tr>
                            <tr class="text-center">
                                <td><input v-model="nama_nilai" type="text" class="form-control" placeholder="Tugas / UTS / UAS"/></td>
                                <td><input v-model="nilai_angka" v-on:change="getNilaiHuruf(nilai_angka)" type="text" class="form-control" placeholder="1 - 100"/></td>
                                <td><input v-model="nilai_huruf" type="text" class="form-control" placeholder=" - " readonly/></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer text-light">
                <button v-on:click="reset" type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
                <button v-on:click="saveNilai('{{$detil_siswa->id_siswa}}')" type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>
{{-- end modal nilai --}}

{{-- modal edit nilai --}}
<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Nilai</h5>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Mapel</th>
                                <th colspan="2">: @{{kode_mapel_detil}}</th>
                            </tr>
                            <tr>
                                <th>Nama Mapel</th>
                                <th colspan="2">: @{{nama_mapel_detil}}</th>
                            </tr>
                            <tr class="text-center">
                                <th class="text-left">Nama Nilai</th>
                                <th class="text-center">Nilai Angka</th>
                                <th class="text-right">Nilai Huruf</th>
                            </tr>
                            <tr class="text-center">
                                <td><input v-model="nama_nilai" type="text" class="form-control" placeholder="Tugas / UTS / UAS"/></td>
                                <td><input v-model="nilai_angka" v-on:change="getNilaiHuruf(nilai_angka)" type="text" class="form-control" placeholder="1 - 100"/></td>
                                <td><input v-model="nilai_huruf" type="text" class="form-control" placeholder=" - " readonly/></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer text-light">
                <button v-on:click="reset" type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
                <button v-if="status" v-on:click="updateNilai('{{$detil_siswa->id_siswa}}')" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>
{{-- end modal nilai --}}
@endsection