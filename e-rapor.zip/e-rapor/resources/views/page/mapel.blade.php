@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Mapel</strong>
                </div>
                <div class="card-body">

                    @if (session('role') == 'admin')
                    <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Mapel</button>
                    @endif
                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Id Mapel</th>
                                <th>Kode Mapel</th>
                                <th>Nama Mapel</th>
                                @if (session('role') == 'admin')
                                <th>Opsi</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($mapel as $item)
                                <tr>
                                    <td>{{$item->id}}</td>
                                    <td>{{$item->kode_mapel}}</td>
                                    <td>{{$item->nama_mapel}}</td>
                                    @if (session('role') == 'admin')
                                    <td>
                                        <button v-on:click="editMapel({{$item->id}})" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusMapel({{$item->id}},'{{$item->nama_mapel}}')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Mapel</div>
                    <div class="card-body card-block">
                        <form action="{{ url('saveMapel') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-book" aria-hidden="true"></i></div>
                                    <input type="text" id="kode_mapel" name="kode_mapel" placeholder="Kode Mapel" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-book" aria-hidden="true"></i></div>
                                    <input type="text" id="mapel" name="mapel" placeholder="Nama Mapel" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}

    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Mapel</div>
                    <div class="card-body card-block">
                        <form action="{{ url('editMapel') }}" method="post" class="">
                            @csrf
                            <input type="hidden" name="id" v-model="id_mapel"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-book" aria-hidden="true"></i></div>
                                    <input v-model="kode_mapel" type="text" id="kode_mapel" name="kode_mapel" placeholder="Kode Mapel" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-book" aria-hidden="true"></i></div>
                                    <input v-model="nama_mapel" type="text" id="mapel" name="mapel" placeholder="Nama Mapel" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}
@endsection