@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data User</strong>
                </div>
                <div class="card-body">
                    <button href="#" class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah User</button>
                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Status</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($data_user as $item)
                                <tr>
                                    <td>{{$item->e_mail}}</td>
                                    <td>{{$item->role}}</td>
                                    <td>
                                        <span class="badge badge-{{ $item->status == 'active' ? 'success' : 'danger' }}">{{$item->status}}</span>
                                    </td>
                                    <td>
                                        @if(session('role') == 'admin')
                                        <button v-on:click="editUser({{$item->id}})" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        @endif

                                        @if(session('role') == 'admin' && $item->role != 'admin')
                                            <button v-on:click="deleteUser({{$item->id}},'{{$item->e_mail}}')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                        @endif

                                        @if ($item->status == "disable")
                                            @switch($item->role)
                                                @case('admin')
                                                    
                                                    @break
                                                @case('guru')
                                                    <button v-on:click="userActivasi({{$item->id}},'{{$item->role}}')" data-toggle="modal" data-target="#modalAktivasiGuru" class="btn btn-outline-info btn-sm"><i class="fa fa-cogs"></i> Aktifkan</button>
                                                    @break

                                                @case('siswa')
                                                    <button v-on:click="userActivasi({{$item->id}},'{{$item->role}}')" data-toggle="modal" data-target="#modalAktivasiSiswa" class="btn btn-outline-info btn-sm"><i class="fa fa-cogs"></i> Aktifkan</button>
                                                    @break

                                                @case('wali_murid')
                                                    <button v-on:click="userActivasi({{$item->id}},'{{$item->role}}')" data-toggle="modal" data-target="#modalAktivasiWaliMurid" class="btn btn-outline-info btn-sm"><i class="fa fa-cogs"></i> Aktifkan</button>
                                                    @break

                                                @case('wali_kelas')
                                                <button v-on:click="userActivasi({{$item->id}},'{{$item->role}}')" data-toggle="modal" data-target="#modalAktivasiWaliKelas" class="btn btn-outline-info btn-sm"><i class="fa fa-cogs"></i> Aktifkan</button>
                                                    @break
                                                @default
                                                    
                                            @endswitch
                                        @else
                                            @if ($item->role != 'admin')
                                                <button v-on:click="userDeactivasi({{$item->id}},'{{$item->role}}','{{$item->e_mail}}')" class="btn btn-outline-info btn-sm"><i class="fa fa-cogs"></i> Non Aktifkan</button>
                                            @endif
                                        @endif

                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('savePengguna') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                                    <input type="email" id="email" name="email" placeholder="Email" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                                    <input type="password" id="password" name="password" placeholder="Password" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Role..." name="role" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="admin">Admin</option>
                                        <option value="siswa">Siswa</option>
                                        <option value="guru">Guru Mapel</option>
                                        <option value="wali_murid">Wali Murid</option>
                                        <option value="wali_kelas">Wali Kelas</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}

    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('editPengguna') }}" method="post">
                            @csrf
                            <input type="hidden" name="id" v-model="id_user">
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-envelope"></i></div>
                                    <input v-model="email" type="email" id="email_edit" name="email" placeholder="Email" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-asterisk"></i></div>
                                    <input v-model="pass_decrypt" type="password" id="password_edit" name="password" placeholder="Password" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">

                                    <select v-model="role" data-placeholder="Choose a Role..." data-width="100%" name="role" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="admin">Admin</option>
                                        <option value="siswa">Siswa</option>
                                        <option value="guru">Guru Mapel</option>
                                        <option value="wali_murid">Wali Murid</option>
                                        <option value="wali_kelas">Wali Kelas</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}

    {{-- modal aktivasi guru --}}

    <div class="modal fade" id="modalAktivasiGuru" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Aktivasi User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('aktivasiGuru') }}" method="post">
                            @csrf

                            <input type="hidden" name="id" v-model="id_user">
                            <div class="form-group">
                                <div class="input-group">

                                    <select v-model="data_rolenya" data-placeholder="Choose a Guru..." data-width="100%" name="guru" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option v-for="(data_rolenya, index) in detil_role" :value="data_rolenya.id_guru_mapel">@{{data_rolenya.nama_guru_mapel}}</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-info btn-sm">Save</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./modal aktivasi guru --}}

    {{-- modal aktivasi siswa --}}

    <div class="modal fade" id="modalAktivasiSiswa" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Aktivasi User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('aktivasiSiswa') }}" method="post">
                            @csrf
                            <input type="hidden" name="id" v-model="id_user">
                            <div class="form-group">
                                <div class="input-group">

                                    <select v-model="data_role_siswa" data-placeholder="Choose a Siswa..." data-width="100%" name="siswa" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option v-for="(data_role_siswa, index) in detil_role" :value="data_role_siswa.id_siswa">@{{data_role_siswa.nama_siswa}}</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-info btn-sm">Save</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./modal aktivasi siswa --}}

    {{-- modal aktivasi siswa --}}

    <div class="modal fade" id="modalAktivasiWaliKelas" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Aktivasi User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('aktivasiWaliKelas') }}" method="post">
                            @csrf
                            <input type="hidden" name="id" v-model="id_user">
                            <div class="form-group">
                                <div class="input-group">

                                    <select v-model="data_role_wali_kelas" data-placeholder="Choose a Wali Kelas..." data-width="100%" name="wali_kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option v-for="(data_role_wali_kelas, index) in detil_role" :value="data_role_wali_kelas.id_wali_kelas">@{{data_role_wali_kelas.nama_guru_mapel}}</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-info btn-sm">Save</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./modal aktivasi siswa --}}

    {{-- modal aktivasi siswa --}}

    <div class="modal fade" id="modalAktivasiWaliMurid" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Aktivasi User</div>
                    <div class="card-body card-block">
                        <form action="{{ url('aktivasiWaliMurid') }}" method="post">
                            @csrf
                            <input type="hidden" name="id" v-model="id_user">
                            <div class="form-group">
                                <div class="input-group">

                                    <select v-model="data_role_wali_murid" data-placeholder="Choose a Wali Murid..." data-width="100%" name="wali_murid" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option v-for="(data_role_wali_murid, index) in detil_role" :value="data_role_wali_murid.id_wali_murid">@{{data_role_wali_murid.nama_wali_murid}}</option>
                                    </select>

                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-info btn-sm">Save</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./modal aktivasi siswa --}}
@endsection