@extends('template.master')
@section('content')
    <!-- Animated -->
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Peringkat</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Posisi</th>
                                    <th>Nama Siswa</th>
                                    <th>Rata Rata</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($peringkat as $i => $item)
                                    @if (session('role') == 'siswa')
                                    <tr class="{{ $item->id_siswa == session('id_user') ? 'bg-primary text-light' : ''}}">
                                    @elseif(session('role') == 'wali_murid')
                                    <tr class="{{ $item->id_siswa == session('id_siswa') ? 'bg-primary text-light' : ''}}">
                                    @else
                                    <tr>
                                    @endif
                                        <td>#{{ $i+1 }}</td>
                                        <td>{{$item->nama_siswa}}</td>
                                        <td>{{$item->rata_rata}}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- /Widgets -->
    </div>
    <!-- .animated -->
@endsection
