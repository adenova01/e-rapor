@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Siswa</strong>
                </div>
                <div class="card-body">

                    @if (session('role') == 'admin')
                    <button v-on:click="setnis" class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Siswa</button>
                    @endif

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>NIS</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                                <th>Jurusan</th>
                                <th>Alamat</th>
                                <th>Rombel</th>
                                @if (session('role') == 'admin')
                                <th>Opsi</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($siswa as $i => $item)
                                <tr>
                                    <td>{{$item->nis}}</td>
                                    <td>{{$item->nama_siswa}}</td>
                                    <td>{{$item->kelas}}</td>
                                    <td>{{$item->nama_jurusan}}</td>
                                    <td>{{$item->alamat}}</td>
                                    <td class="text-center">{{$item->rombel_id}}</td>
                                    @if (session('role') == 'admin')
                                    <td>
                                        <button v-on:click="editSiswa({{$item->id_siswa}})" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm m-2"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusSiswa({{$item->id_siswa}},'{{$item->nama_siswa}}')" class="btn btn-outline-danger btn-sm m-2"><i class="fa fa-trash"></i> Hapus</button>
                                        <button v-on:click="id_siswa = {{$item->id_siswa}}" data-toggle="modal" data-target="#modalAddRombel" class="btn btn-outline-info btn-sm m-2"><i class="fa fa-plus"></i> Add / Edit Rombel</button>
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Siswa</div>
                    <div class="card-body card-block">
                        <form action="{{ url('saveSiswa') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nis" type="text" id="nis" name="nis" placeholder="Nis" class="form-control" required readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input type="text" id="Nama" name="Nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XII</option>
                                        <option value="XIII">XIII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                        <option value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}

    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Siswa</div>
                    <div class="card-body card-block">
                        <form action="{{ url('editSiswa/') }}" method="post" class="">
                            @csrf
                            <input type="hidden" v-model="id_siswa" name="id"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nis" type="text" id="nis1" name="nis" placeholder="Nis" class="form-control" required readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_siswa" type="text" id="Nama1" name="Nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas" data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XI</option>
                                        <option value="XIII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan" data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        @php $id_jurusan = "{{jurusan}}" @endphp
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                        <option {{$id_jurusan == $item->id ? 'selected' : ''}} value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea v-model="alamat_siswa" type="text" id="alamat1" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Update</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}

    {{-- ======================== --}}

    {{-- modal add --}}

    <div class="modal fade" id="modalAddRombel" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Rombel</div>
                    <div class="card-body card-block">
                        <form action="{{ url('addRombel') }}" method="post" class="">
                            @csrf

                            <input type="hidden" name="id_siswa" v-model="id_siswa" />

                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="rombel" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($rombel as $item)
                                            <option value="{{$item->id}}">{{$item->nama_rombel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}
@endsection