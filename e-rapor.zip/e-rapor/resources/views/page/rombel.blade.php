@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Rombel</strong>
                </div>
                <div class="card-body">

                    @if (session('role') == 'admin')
                    <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-users"></i> Tambah Rombel</button>
                    @endif

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Kode Rombel</th>
                                <th>Nama Rombel</th>
                                <th>Jurusan</th>
                                <th>Kelas</th>
                                <th>Tahun Ajar</th>
                                <th>Semester</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($rombel as $item)
                                <tr>
                                    <td>{{$item->kode_rombel}}</td>
                                    <td>{{$item->nama_rombel}}</td>
                                    <td>{{$item->nama_jurusan}}</td>
                                    <td>{{$item->kelas}}</td>
                                    <td>{{$item->tahun_ajar}}</td>
                                    <td>{{$item->semester}}</td>
                                    <td>
                                        <a href="{{ url('/detilrombel'.'/'.$item->id) }}" class="btn btn-outline-info btn-sm"><i class="fa fa-eye"></i> Detil</a>

                                        @if (session('role') == 'admin')
                                        <button v-on:click="getRombel({{$item->id}})" data-toggle="modal" data-target="#editModal" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Edit</button>
                                        <button v-on:click="deleteRombel({{$item->id}},'{{$item->kode_rombel}}')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash-o"></i> Delete</button>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Rombel</div>
                    <div class="card-body card-block">
                        <form action="{{ url('saveRombel') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="text" id="kode_rombel" name="kode_rombel" placeholder="Kode Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="text" id="nama_rombel" name="nama_rombel" placeholder="Nama Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                        <option value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Mapel..." name="mapel[]" data-width="100%" multiple class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        @foreach ($mapel as $item)
                                        <option value="{{$item->id}}">{{$item->nama_mapel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                    <input type="text" id="Tahun Ajar" name="tahun_ajar" placeholder="Tahun Ajaran" class="form-control" required>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3"><label class=" form-control-label">Semester</label></div>
                                <div class="col col-md-8">
                                    <div class="form-check-inline form-check">
                                        <label for="inline-radio1" class="form-check-label m-1">
                                            <input type="radio" checked id="inline-radio1" name="semester" value="ganjil" class="form-check-input">Ganjil 
                                        </label>
                                        <label for="inline-radio2" class="form-check-label m-1">
                                            <input type="radio" id="inline-radio2" name="semester" value="genap" class="form-check-input">Genap
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Rombel</div>
                    <div class="card-body card-block">
                        <form action="{{ url('editRombel') }}" method="post" class="">
                            @csrf
                            <input type="hidden" v-model="id_rombel" name="id_rombel"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="kode_rombel" type="text" id="kode_rombel" name="kode_rombel" placeholder="Kode Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_rombel" type="text" id="nama_rombel" name="nama_rombel" placeholder="Nama Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan_rombel" data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                        <option value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas_rombel" data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XII</option>
                                        <option value="XIII">XIII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="mapel_rombel" data-placeholder="Choose a Mapel..." name="mapel[]" data-width="100%" multiple class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        @foreach ($mapel as $item)
                                        <option value="{{$item->id}}">{{$item->nama_mapel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                    <input v-model="tahun_ajar" type="text" id="Tahun Ajar" name="tahun_ajar" placeholder="Tahun Ajaran" class="form-control" required>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3"><label class=" form-control-label">Semester</label></div>
                                <div class="col col-md-8">
                                    <div class="form-check-inline form-check">
                                        {{-- @php $smst = "{{semester}}" @endphp --}}
                                        <label for="inline-radio1" class="form-check-label m-1">
                                            <input v-model="semester" type="radio" id="inline-radio1" name="semester" value="ganjil" class="form-check-input">Ganjil 
                                        </label>
                                        <label for="inline-radio2" class="form-check-label m-1">
                                            <input v-model="semester" type="radio" id="inline-radio2" name="semester" value="genap" class="form-check-input">Genap
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Ubah</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}

    {{-- ======================== --}}
@endsection