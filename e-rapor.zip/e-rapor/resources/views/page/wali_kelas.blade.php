@extends('template.master')
@section('content')
    <div class="row">
        <div class="col-sm-12">
            
            @if (session('message'))
                <div class="alert alert-info text-center">{{session('message')}}</div>
            @endif

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Wali Kelas</strong>
                </div>
                <div class="card-body">

                    @if (session('role') == 'admin')
                        <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Wali Kelas</button>
                    @endif

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Nama</th>
                                <th>Kelas</th>
                                <th>Jurusan</th>
                                @if (session('role') == 'admin')
                                <th>Opsi</th>
                                @endif
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($walikelas as $item)
                                <tr>
                                    <td>{{$item->nama_guru_mapel}}</td>
                                    <td>{{$item->pengampu_kelas}}</td>
                                    <td>{{$item->nama_jurusan}}</td>
                                    @if (session('role') == 'admin')
                                    <td>
                                        <button v-on:click="detilWaliKelas({{$item->id_wali_kelas}})" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusWaliKelas({{$item->id_wali_kelas}},'{{$item->nip}}')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                    </td>
                                    @endif
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    {{-- modal add --}}

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Guru</div>
                    <div class="card-body card-block">
                        <form action="{{ url('saveWaliKelas') }}" method="post" class="">
                            @csrf
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Guru..." data-width="100%" name="nip" class="js-example-basic-single" required>
                                        @foreach ($guru as $item)
                                            <option value="" label="default"></option>
                                            <option value="{{$item->nip}}">{{$item->nama_guru_mapel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                            <option value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal add --}}

    {{-- modal edit --}}
    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Wali Kelas</div>
                    <div class="card-body card-block">
                        <form action="{{ url('editWaliKelas') }}" method="post" class="">
                            @csrf
                            <input type="hidden" name="id_wali_kelas" v-model="id_wali_kelas" />
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="nip_wali_kelas" data-placeholder="Choose a Guru..." data-width="100%" name="nip" class="js-example-basic-single" required>
                                        @foreach ($guru as $item)
                                            <option value="" label="default"></option>
                                            <option value="{{$item->nip}}">{{$item->nama_guru_mapel}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas_wali" data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan_wali" data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        @foreach ($jurusan as $item)
                                            <option value="{{$item->id}}">{{$item->nama_jurusan}}</option>
                                        @endforeach
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- ./ modal edit --}}
@endsection