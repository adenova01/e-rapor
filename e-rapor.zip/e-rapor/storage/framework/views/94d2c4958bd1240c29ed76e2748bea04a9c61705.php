<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Rombel</strong>
                </div>
                <div class="card-body">

                    <?php if(session('role') == 'admin'): ?>
                    <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-users"></i> Tambah Rombel</button>
                    <?php endif; ?>

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Kode Rombel</th>
                                <th>Nama Rombel</th>
                                <th>Jurusan</th>
                                <th>Kelas</th>
                                <th>Tahun Ajar</th>
                                <th>Semester</th>
                                <th>Opsi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->kode_rombel); ?></td>
                                    <td><?php echo e($item->nama_rombel); ?></td>
                                    <td><?php echo e($item->nama_jurusan); ?></td>
                                    <td><?php echo e($item->kelas); ?></td>
                                    <td><?php echo e($item->tahun_ajar); ?></td>
                                    <td><?php echo e($item->semester); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/detilrombel'.'/'.$item->id)); ?>" class="btn btn-outline-info btn-sm"><i class="fa fa-eye"></i> Detil</a>

                                        <?php if(session('role') == 'admin'): ?>
                                        <button v-on:click="getRombel(<?php echo e($item->id); ?>)" data-toggle="modal" data-target="#editModal" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Edit</button>
                                        <button v-on:click="deleteRombel(<?php echo e($item->id); ?>,'<?php echo e($item->kode_rombel); ?>')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash-o"></i> Delete</button>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Rombel</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('saveRombel')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="text" id="kode_rombel" name="kode_rombel" placeholder="Kode Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="text" id="nama_rombel" name="nama_rombel" placeholder="Nama Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Mapel..." name="mapel[]" data-width="100%" multiple class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_mapel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                    <input type="text" id="Tahun Ajar" name="tahun_ajar" placeholder="Tahun Ajaran" class="form-control" required>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3"><label class=" form-control-label">Semester</label></div>
                                <div class="col col-md-8">
                                    <div class="form-check-inline form-check">
                                        <label for="inline-radio1" class="form-check-label m-1">
                                            <input type="radio" checked id="inline-radio1" name="semester" value="ganjil" class="form-check-input">Ganjil 
                                        </label>
                                        <label for="inline-radio2" class="form-check-label m-1">
                                            <input type="radio" id="inline-radio2" name="semester" value="genap" class="form-check-input">Genap
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    

    <div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Rombel</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('editRombel')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" v-model="id_rombel" name="id_rombel"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="kode_rombel" type="text" id="kode_rombel" name="kode_rombel" placeholder="Kode Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_rombel" type="text" id="nama_rombel" name="nama_rombel" placeholder="Nama Rombel" class="form-control" required >
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan_rombel" data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas_rombel" data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XII</option>
                                        <option value="XIII">XIII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="mapel_rombel" data-placeholder="Choose a Mapel..." name="mapel[]" data-width="100%" multiple class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_mapel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-calendar" aria-hidden="true"></i></div>
                                    <input v-model="tahun_ajar" type="text" id="Tahun Ajar" name="tahun_ajar" placeholder="Tahun Ajaran" class="form-control" required>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col col-md-3"><label class=" form-control-label">Semester</label></div>
                                <div class="col col-md-8">
                                    <div class="form-check-inline form-check">
                                        
                                        <label for="inline-radio1" class="form-check-label m-1">
                                            <input v-model="semester" type="radio" id="inline-radio1" name="semester" value="ganjil" class="form-check-input">Ganjil 
                                        </label>
                                        <label for="inline-radio2" class="form-check-label m-1">
                                            <input v-model="semester" type="radio" id="inline-radio2" name="semester" value="genap" class="form-check-input">Genap
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Ubah</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/rombel.blade.php ENDPATH**/ ?>