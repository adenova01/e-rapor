<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Guru</strong>
                </div>
                <div class="card-body">

                    <?php if(session('role') == 'admin'): ?>
                        <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Guru</button>
                    <?php endif; ?>

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Nip</th>
                                <th>Nama Guru</th>
                                <th>Pengampu Mapel</th>
                                <th>Alamat</th>
                                <?php if(session('role') == 'admin'): ?>
                                <th>Opsi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <?php if(session('id_user') == $item->id_guru_mapel && session('role') == 'guru'): ?>    
                                        <td><?php echo e($item->nip); ?></td>
                                        <td><?php echo e($item->nama_guru_mapel); ?></td>
                                        <td>
                                            <?php for($a = 0; $a < count($mapel_arry[$i]); $a++): ?>
                                            <span class="badge badge-info badge-md"><?php echo e($mapel_arry[$i][$a]->nama_mapel); ?></span>
                                            <?php endfor; ?>
                                        </td>
                                        <td><?php echo e($item->alamat); ?></td>
                                    <?php endif; ?>

                                    <?php if(session('role') == 'admin' || session('role') != 'guru'): ?>
                                        <td><?php echo e($item->nip); ?></td>
                                        <td><?php echo e($item->nama_guru_mapel); ?></td>
                                        <td>
                                            <?php for($a = 0; $a < count($mapel_arry[$i]); $a++): ?>
                                            <span class="badge badge-info badge-md"><?php echo e($mapel_arry[$i][$a]->nama_mapel); ?></span>
                                            <?php endfor; ?>
                                        </td>
                                        <td><?php echo e($item->alamat); ?></td>
                                    <?php endif; ?>

                                    <?php if(session('role') == 'admin'): ?>
                                    <td>
                                        <button v-on:click="editGuru(<?php echo e($item->id_guru_mapel); ?>)" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusGuru(<?php echo e($item->id_guru_mapel); ?>, '<?php echo e($item->nama_guru_mapel); ?>')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Guru</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('saveGuru')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input type="number" id="nip" name="nip" placeholder="Nip" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input type="text" id="Nama" name="nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Mapel..." name="mapel[]" data-width="100%" multiple class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_mapel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    
    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Mapel</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('editGuru')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" v-model="id_guru"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nip" type="number" id="nip1" name="nip" placeholder="Nip" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_guru" type="text" id="Nama1" name="nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <?php
                                        $kode_mapel[] = "{{arry_pengampu_mapel}}";
                                    ?>

                                    <select v-model="arry_pengampu_mapel" data-placeholder="Choose a Mapel..." name="mapel[]" multiple="multiple" data-width="100%" class="js-example-basic-multiple" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $mapel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php echo e(in_array($item['id'], $kode_mapel) ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nama_mapel); ?></option>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea v-model="alamat_guru" type="text" id="alamat1" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/guru.blade.php ENDPATH**/ ?>