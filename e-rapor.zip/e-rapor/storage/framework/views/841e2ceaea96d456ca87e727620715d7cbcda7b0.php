<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Detil Siswa</strong>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="col-2">NIS</th>
                            <td class="col-1">:</td>
                            <td><?php echo e($detil_siswa->nis); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Nama</th>
                            <td>:</td>
                            <td><?php echo e($detil_siswa->nama_siswa); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>:</td>
                            <td><?php echo e($detil_siswa->kelas); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <td>:</td>
                            <td><?php echo e($detil_siswa->nama_jurusan); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Semester</th>
                            <td>:</td>
                            <td><?php echo e($detil_siswa->semester); ?></td>
                            <th>Tahun Ajar</th>
                            <td><?php echo e($detil_siswa->tahun_ajar); ?></td>
                        </tr>
                        <tr>
                            <th>Kode Rombel</th>
                            <td>:</td>
                            <td><span class="badge badge-info"><?php echo e($detil_siswa->kode_rombel); ?></span></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Mapel</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Kode Mapel</th>
                                    <th>Nama Mapel</th>
                                    <th>Opsi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if($detil_mapel[0] != null): ?>
                                    <?php for($i=0; $i<count($detil_mapel); $i++): ?>
                                    <tr>
                                        <td><?php echo e($detil_mapel[$i]->kode_mapel); ?></td>
                                        <td><?php echo e($detil_mapel[$i]->nama_mapel); ?></td>
                                        <td>
                                            <button v-on:click="getDetilMapel(<?php echo e($detil_mapel[$i]->id); ?>)" data-toggle="modal" data-target="#mediumModal" class="btn btn-info btn-sm"><span class="fa fa-pencil"></span> Isi Nilai</button>
                                            
                                            <button v-on:click="getDetilNilaiSiswa(<?php echo e($detil_mapel[$i]->id); ?>, <?php echo e($detil_siswa->id_siswa); ?>)" data-toggle="modal" data-target="#editModal" class="btn btn-secondary btn-sm"><span class="fa fa-edit"></span> Edit Nilai</button>
                                            
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                <?php else: ?> 
                                    <tr>
                                        <td class="text-center" colspan="3">Tidak Ada Mapel Yang di Ampu</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Nilai</h5>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Mapel</th>
                                <th colspan="2">: {{kode_mapel_detil}}</th>
                            </tr>
                            <tr>
                                <th>Nama Mapel</th>
                                <th colspan="2">: {{nama_mapel_detil}}</th>
                            </tr>
                            <tr class="text-center">
                                <th class="text-left">Nama Nilai</th>
                                <th class="text-center">Nilai Angka</th>
                                <th class="text-right">Nilai Huruf</th>
                            </tr>
                            <tr class="text-center">
                                <td><input v-model="nama_nilai" type="text" class="form-control" placeholder="Tugas / UTS / UAS"/></td>
                                <td><input v-model="nilai_angka" v-on:change="getNilaiHuruf(nilai_angka)" type="text" class="form-control" placeholder="1 - 100"/></td>
                                <td><input v-model="nilai_huruf" type="text" class="form-control" placeholder=" - " readonly/></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer text-light">
                <button v-on:click="reset" type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
                <button v-on:click="saveNilai('<?php echo e($detil_siswa->id_siswa); ?>')" type="button" class="btn btn-primary">Save</button>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="editModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Nilai</h5>
            </div>
            <div class="modal-body">
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <th>Kode Mapel</th>
                                <th colspan="2">: {{kode_mapel_detil}}</th>
                            </tr>
                            <tr>
                                <th>Nama Mapel</th>
                                <th colspan="2">: {{nama_mapel_detil}}</th>
                            </tr>
                            <tr class="text-center">
                                <th class="text-left">Nama Nilai</th>
                                <th class="text-center">Nilai Angka</th>
                                <th class="text-right">Nilai Huruf</th>
                            </tr>
                            <tr class="text-center">
                                <td><input v-model="nama_nilai" type="text" class="form-control" placeholder="Tugas / UTS / UAS"/></td>
                                <td><input v-model="nilai_angka" v-on:change="getNilaiHuruf(nilai_angka)" type="text" class="form-control" placeholder="1 - 100"/></td>
                                <td><input v-model="nilai_huruf" type="text" class="form-control" placeholder=" - " readonly/></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="modal-footer text-light">
                <button v-on:click="reset" type="button" class="btn btn-warning" data-dismiss="modal">Cancel</button>
                <button v-if="status" v-on:click="updateNilai('<?php echo e($detil_siswa->id_siswa); ?>')" type="button" class="btn btn-primary">Update</button>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/page/isi_nilai.blade.php ENDPATH**/ ?>