<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Wali Kelas</strong>
                </div>
                <div class="card-body">

                    <?php if(session('role') == 'admin'): ?>
                        <button class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Wali Kelas</button>
                    <?php endif; ?>

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>Nama</th>
                                <th>Kelas</th>
                                <th>Jurusan</th>
                                <?php if(session('role') == 'admin'): ?>
                                <th>Opsi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $walikelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nama_guru_mapel); ?></td>
                                    <td><?php echo e($item->pengampu_kelas); ?></td>
                                    <td><?php echo e($item->nama_jurusan); ?></td>
                                    <?php if(session('role') == 'admin'): ?>
                                    <td>
                                        <button v-on:click="detilWaliKelas(<?php echo e($item->id_wali_kelas); ?>)" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusWaliKelas(<?php echo e($item->id_wali_kelas); ?>,'<?php echo e($item->nip); ?>')" class="btn btn-outline-danger btn-sm"><i class="fa fa-trash"></i> Hapus</button>    
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Guru</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('saveWaliKelas')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Guru..." data-width="100%" name="nip" class="js-example-basic-single" required>
                                        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="" label="default"></option>
                                            <option value="<?php echo e($item->nip); ?>"><?php echo e($item->nama_guru_mapel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    
    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Wali Kelas</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('editWaliKelas')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id_wali_kelas" v-model="id_wali_kelas" />
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="nip_wali_kelas" data-placeholder="Choose a Guru..." data-width="100%" name="nip" class="js-example-basic-single" required>
                                        <?php $__currentLoopData = $guru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="" label="default"></option>
                                            <option value="<?php echo e($item->nip); ?>"><?php echo e($item->nama_guru_mapel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas_wali" data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XI">XI</option>
                                        <option value="XII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan_wali" data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/wali_kelas.blade.php ENDPATH**/ ?>