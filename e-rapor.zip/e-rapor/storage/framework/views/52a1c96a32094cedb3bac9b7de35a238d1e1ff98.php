<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Siswa</strong>
                </div>
                <div class="card-body">
                    <table class="table">
                        <tbody>
                            <tr>
                                <td>Nis</td>
                                <td>:</td>
                                <td><?php echo e($siswa->nis); ?></td>
                            </tr>
                            <tr>
                                <td>Nama Siswa</td>
                                <td>:</td>
                                <td><?php echo e($siswa->nama_siswa); ?></td>
                            </tr>
                            <tr>
                                <td>Rombel</td>
                                <td>:</td>
                                <td><?php echo e($siswa->rombel_id); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Pengisian Rapor</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="form-group mb-3 col-6">
                            <label for="kriteria">Kriteria Lulus</label>
                            <input v-model="standar_lulus" id="kriteria" type="text" class="form-control" placeholder="Kriteria Ketuntasan Minimal" aria-label="Recipient's username" aria-describedby="button-addon2" 
                            onKeyUp="if(this.value>=100){this.value='100';}else if(this.value<0){this.value='0';}">
                        </div>
                        <div class="form-group mb-3 col-6">
                            <label for="inputGroupSelect01">Kategori Mata Pelajaran</label>
                            <select v-model="kategori" class="custom-select" id="inputGroupSelect01">
                              <option>A</option>
                              <option>B</option>
                            </select>
                        </div>
                    </div>
                    <table class="table">
                        <tbody>
                            <thead>
                                <tr>
                                    <th>Nama Mapel</th>
                                    <th>Nilai Rapor</th>
                                    <th>Predikat</th>
                                    <th>Catatan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="(rapor, index) in data_rapor">
                                    <td>
                                        <select v-model="rapor.id_mapel" class="custom-select" id="inputGroupSelect01" v-on:change="removeMapel">
                                            <option v-for="(mapel, index) in all_mapel" :value="mapel.id">{{mapel.nama_mapel}}</option>
                                        </select>
                                    </td>
                                    <td>
                                        <input v-model="rapor.nilai_rapor" type="number" min="0" max="100" 
                                        onKeyUp="if(this.value>=100){this.value='100';}else if(this.value<0){this.value='0';}" 
                                        class="form-control" v-on:change="cek(index)">
                                    </td>
                                    <td><input readonly v-model="rapor.predikat" type="text" class="form-control"></td>
                                    <td><textarea v-model="rapor.catatan" type="text" class="form-control" style="height: 100px;"></textarea></td>
                                </tr>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="3">
                                        <button v-on:click="saveRapor" class="btn btn-outline-success"><span class="fa fa-save"></span> Simpan</button>
                                    </td>
                                    <td colspan="2">
                                        <button v-on:click="addRowRapor" class="btn btn-outline-info"><span class="fa fa-plus"></span> Add Row</button>
                                        <button v-on:click="removeRowRapor" v-if="data_rapor.length > 1" class="btn btn-outline-danger"><span class="fa fa-trash"></span> Delete Row</button>
                                    </td>
                                </tr>
                            </tfoot>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/isi_rapor.blade.php ENDPATH**/ ?>