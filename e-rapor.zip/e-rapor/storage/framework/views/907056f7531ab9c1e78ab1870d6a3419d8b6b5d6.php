<!doctype html>
<html class="no-js" lang="">
<head>
    <?php echo $__env->make('template.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <!-- Left Panel -->
    <?php echo $__env->make('template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /#left-panel -->
    <!-- Right Panel -->
    <div id="right-panel" class="right-panel">
        <!-- Header-->
        <?php echo $__env->make('template.top_nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /#header -->
        <!-- Content -->
        <div class="content" id="app">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <!-- /.content -->
        <div class="clearfix"></div>
        <!-- Footer -->
        <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /.site-footer -->
    </div>
    <!-- /#right-panel -->

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
    <script src="<?php echo e(url('/assets/js/main.js')); ?>"></script>

    
    
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/datatables.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/buttons.bootstrap.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/jszip.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/vfs_fonts.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/buttons.html5.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/buttons.print.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/lib/data-table/buttons.colVis.min.js"></script>
    <script src="<?php echo e(url('')); ?>/assets/js/init/datatables-init.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/axios/dist/axios.min.js"></script>
    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!--  Chart js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js@2.7.3/dist/Chart.bundle.min.js"></script>

    <?php echo $__env->make('library.vue', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script type="text/javascript">
        $(document).ready(function() {
            $('.js-example-basic-single').select2();
            $('.js-example-basic-multiple').select2();
            $('#myTable').DataTable();
        });
    </script>
</body>
</html>
<?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/template/master.blade.php ENDPATH**/ ?>