<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        
        <?php if(session('message')): ?>
            <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <strong class="card-title"><?php echo e($nama_siswa->nis); ?> - <?php echo e($nama_siswa->nama_siswa); ?></strong>
                <a href="<?php echo e(url('/nilai')); ?>" class="btn btn-primary btn-sm" style="float:right; margin-right: 15px"><span class="fa fa-arrow-left"></span> back</a>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>Nama Mapel</th>
                            <th>Nama Nilai</th>
                            <th>Nilai</th>
                            <th>Nilai Huruf</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detil_nilai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->nama_mapel); ?></td>
                                <td><?php echo e($item->nama_nilai); ?></td>
                                <td><?php echo e($item->nilai); ?></td>
                                <td><?php echo e($item->nilai_huruf); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/page/detil_nilai.blade.php ENDPATH**/ ?>