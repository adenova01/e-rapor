<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">
        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">

                

                
                <?php if(session('role') == 'admin'): ?>
                    
                    <li class="<?php echo e($slug == 'dashboard' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/dashboard')); ?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'guru' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/guru')); ?>"><i class="menu-icon fa fa-users"></i>Guru</a>
                    </li>

                    <li class="<?php echo e($slug == 'wali_kelas' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/waliKelas')); ?>"><i class="menu-icon fa fa-users"></i>Wali Kelas</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'mapel' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/mapel')); ?>"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>
                        
                    <li class="<?php echo e($slug == 'rombel' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/rombel')); ?>"><i class="menu-icon fa fa-users"></i>Rombel</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'rapor' ? 'cative' : ''); ?>">
                        <a href="<?php echo e(url('/rapor')); ?>"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'nilai' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('nilai')); ?>"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="">
                        <a href="#"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="<?php echo e($slug == 'siswa' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/siswa')); ?>"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'jurusan' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/jurusan')); ?>"><i class="menu-icon fa fa-th-list"></i>Jurusan</a>
                    </li>
                    
                    
                    <li class="">
                        <a href="#"> <i class="menu-icon fa fa-user"></i>Wali Murid</a>
                    </li>
                    
                    
                    <li class="menu-title">Extras</li><!-- /.menu-title -->
                    
                    <li class="<?php echo e($slug == 'adduser' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/pengguna')); ?>"><i class="menu-icon fa fa-user-circle-o" aria-hidden="true"></i>User Pengguna</a>
                    </li>
                    
                <?php endif; ?>
                

                

                
                <?php if(session('role') == 'guru'): ?>
                    <li class="<?php echo e($slug == 'dashboard' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/dashboard')); ?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'guru' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/guru')); ?>"><i class="menu-icon fa fa-users"></i>Guru</a>
                    </li>

                    <li class="<?php echo e($slug == 'mapel' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/mapel')); ?>"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>

                    <li class="<?php echo e($slug == 'nilai' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('nilai')); ?>"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>

                    <li class="">
                        <a href="#"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>
                <?php endif; ?>
                

                

                
                <?php if(session('role') == 'wali_kelas'): ?>
                    <li class="<?php echo e($slug == 'dashboard' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/dashboard')); ?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>

                    <li class="<?php echo e($slug == 'wali_kelas' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/waliKelas')); ?>"><i class="menu-icon fa fa-users"></i>Wali Kelas</a>
                    </li>

                    <li class="<?php echo e($slug == 'mapel' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/mapel')); ?>"><i class="menu-icon fa fa-book" aria-hidden="true"></i>Mapel</a>
                    </li>

                    <li class="<?php echo e($slug == 'rombel' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/rombel')); ?>"><i class="menu-icon fa fa-users"></i>Rombel</a>
                    </li>

                    <li class="">
                        <a href="<?php echo e(url('/rapor')); ?>"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'nilai' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('nilai')); ?>"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="">
                        <a href="#"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="<?php echo e($slug == 'siswa' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/siswa')); ?>"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                <?php endif; ?>
                

                

                
                <?php if(session('role') == 'siswa' || session('role') == 'wali_murid'): ?>
                    <li class="<?php echo e($slug == 'dashboard' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/dashboard')); ?>"><i class="menu-icon fa fa-dashboard"></i>Dashboard </a>
                    </li>

                    <li class="<?php echo e($slug == 'rapor' ? 'cative' : ''); ?>">
                        <a href="<?php echo e(url('/rapor')); ?>"> <i class="menu-icon fa fa-book"></i>Rapor</a>
                    </li>
                    
                    <li class="<?php echo e($slug == 'nilai' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('nilai')); ?>"> <i class="menu-icon fa fa-edit"></i>Nilai </a>
                    </li>
                    
                    <li class="">
                        <a href="#"> <i class="menu-icon fa fa-area-chart"></i>Peringkat</a>
                    </li>

                    <li class="<?php echo e($slug == 'siswa' ? 'active' : ''); ?>">
                        <a href="<?php echo e(url('/siswa')); ?>"><i class="menu-icon fa fa-graduation-cap"></i>Siswa</a>
                    </li>
                <?php endif; ?>
                
                
                <li class="">
                    <a href="<?php echo e(url('logout')); ?>"> <i class="menu-icon fa fa-sign-out"></i>Logout</a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside>
<?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/template/sidebar.blade.php ENDPATH**/ ?>