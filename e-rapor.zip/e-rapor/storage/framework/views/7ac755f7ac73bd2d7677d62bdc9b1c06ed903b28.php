<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Detil Rombel</strong>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="col-2">Kode Rombel</th>
                            <td class="col-1">:</td>
                            <td><?php echo e($rombel->kode_rombel); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <td>:</td>
                            <td><?php echo e($rombel->nama_jurusan); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>:</td>
                            <td><?php echo e($rombel->kelas); ?></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Semester</th>
                            <td>:</td>
                            <td><?php echo e($rombel->semester); ?></td>
                            <th>Tahun Ajar</th>
                            <td><?php echo e($rombel->tahun_ajar); ?></td>
                        </tr>
                        <tr>
                            <th>Jumlah Mapel</th>
                            <td>:</td>
                            <td><span class="badge badge-info"><?php echo e(count(explode(',',$rombel->id_mapel))); ?></span></td>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th>Jumlah Siswa</th>
                            <td>:</td>
                            <td><span class="badge badge-info"><?php echo e($jumlah_siswa); ?></span></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-sm-12">
        <div class="row">
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Mapel</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Kode Mapel</th>
                                    <th>Nama Mapel</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php for($i=0; $i<count($data_mapel[0]); $i++): ?>
                                <tr>
                                    <td><?php echo e($data_mapel[1][$i]); ?></td>
                                    <td><?php echo e($data_mapel[0][$i]); ?></td>
                                </tr>
                                <?php endfor; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-sm-6">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Data Siswa</strong>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>NIS</th>
                                    <th>Nama Siswa</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama_siswa); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/detil_rombel.blade.php ENDPATH**/ ?>