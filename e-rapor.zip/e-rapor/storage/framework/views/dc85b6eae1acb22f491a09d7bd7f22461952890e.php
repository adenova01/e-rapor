<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Rapor</strong>
                </div>
                <div class="card-body">
                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>NIS</th>
                                <th>Nama Siswa</th>
                                <th>Alamat</th>
                                <?php if(session('role') == 'wali_kelas' || session('role') == 'wali_murid' || session('role') == 'siswa'): ?>
                                    <th>Rapor</th>
                                <?php endif; ?>
                                <th>Status Rapor</th>
                                <?php if(session('role') == 'wali_kelas' || session('role') == 'admin' || session('role') == 'guru'): ?>
                                <th>Opsi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if($siswa_rapor != null): ?>
                            <?php $__currentLoopData = $siswa_rapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama_siswa); ?></td>
                                    <td><?php echo e($item->alamat); ?></td>
                                    <?php if(session('role') == 'wali_kelas'): ?>
                                    <td class="text-center">
                                        <?php $__currentLoopData = $status_rapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($row->id_siswa == $item->id_siswa): ?>
                                            <a href="<?php echo e(url('rapor/lihat'.'/'.$item->id_siswa)); ?>" target="_blank" class="text-danger"><i class="fa fa-file-pdf-o" style="font-size: 50pt"></i></a>
                                            <p><?php echo e($item->nis.'_'.$item->nama_siswa); ?>.pdf</p>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <?php endif; ?>

                                    <td>
                                        <?php if(count($siswa_rapor) == 0): ?>
                                            <span class="badge badge-warning">Belum Ada Rapor</span>
                                        <?php endif; ?>
                                        <?php if(count($status_rapor) != 0): ?>
                                            <?php $__currentLoopData = $status_rapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($item->id_siswa == $row->id_siswa): ?>
                                                    <span class="badge badge-<?php echo e($row->status == 'selesai' ? 'success' : 'info'); ?>"><?php echo e($row->status); ?></span>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <button v-on:click="getNilaiSiswa(<?php echo e($item->id_siswa); ?>)" class="btn btn-outline-primary btn-sm" data-toggle="modal" data-target="#modalNilai"><i class="fa fa-eye"></i> Lihat Nilai</button>
                                        
                                        <?php if(session('role') == 'wali_kelas'): ?>
                                            <a href="<?php echo e(url('/rapor/isi_nilai/'.$item->id_siswa)); ?>" class="btn btn-outline-success btn-sm"><i class="fa fa-edit"></i> Isi Rapor</a>    
                                        <?php endif; ?>

                                        <?php if(count($status_rapor) != 0): ?>
                                            <?php $__currentLoopData = $status_rapor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if($row->id_siswa == $item->id_siswa && $row->status == 'selesai'): ?>
                                                    <a href="<?php echo e(url('rapor/download'.'/'.$item->id_siswa)); ?>" class="btn btn-outline-primary btn-sm"><i class="fa fa-download"></i> Download Rapor</a>
                                                <?php endif; ?>

                                                <?php if($item->id_siswa == $row->id_siswa && $row->status != 'selesai' && session('role') == 'wali_kelas'): ?>
                                                    <button v-on:click="updateRaporStatus(<?php echo e($item->id_siswa); ?>)" class="btn btn-outline-success btn-sm"><i class="fa fa-check"></i> Selesai</button>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    

    <div class="modal fade" id="modalNilai" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Detil Nilai</div>
                    <div class="card-body card-block">
                        <table class="table table-striped">
                            <thead class="bg-dark text-light">
                                <tr>
                                    <td>Nama Mapel</td>
                                    <td>Nilai</td>
                                    <td>Huruf</td>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="nilai in data_nilai">
                                    <td>{{nilai.nama_mapel}}</td>
                                    <td>{{nilai.nilai}}</td>
                                    <td>{{nilai.nilai_huruf}}</td>
                                </tr>
                                <tr class="bg-dark text-light">
                                    <th>Rata-rata</th>
                                    <th>{{nilai_rata}}</th>
                                    <th>{{nilai_rata_huruf}}</th>
                                </tr>
                            </tbody>
                        </table>
                        <div class="form-actions form-group">
                            <button type="button" class="btn btn-secondary btn-sm text-right" data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/rapor.blade.php ENDPATH**/ ?>