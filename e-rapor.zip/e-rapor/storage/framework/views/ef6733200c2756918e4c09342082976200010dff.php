
<script>

var app = new Vue({
    el: '#app',
    data: {
        url: "<?php echo e(url('/api')); ?>",
        // user
        id_user: '',
        email: '',
        password: '',
        pass_decrypt:'',
        role: '',
        detil_role: [],
        data_rolenya: '',
        data_role_siswa: '',
        data_role_wali_kelas: '',
        // siswa
        nis: '',
        id_siswa: '',
        nama_siswa: '',
        alamat_siswa: '',
        kelas: '',
        jurusan: '',
        // mapel
        id_mapel: '',
        nama_mapel: '',
        kode_mapel: '',
        // guru
        nip: '',
        nama_guru: '',
        pengampu_mapel: '',
        arry_pengampu_mapel: [],
        alamat_guru: '',
        id_guru: '',
        // wali kelas
        nip_wali_kelas: '',
        kelas_wali: '',
        jurusan_wali: '',
        id_wali_kelas: '',
        // jurusan
        id_jurusan: '',
        kode_jurusan: '',
        nama_jurusan: '',
        // rombel
        id_rombel: '',
        kode_rombel: '',
        jurusan_rombel: '',
        kelas_rombel: '',
        wali_kelas_rombel: '',
        mapel_rombel: [],
        tahun_ajar: '',
        semester: '',
        // nilai
        kode_mapel_detil: '',
        nama_mapel_detil: '',
        nama_nilai: '',
        nilai_angka: '',
        nilai_huruf: '',
        nilai_id_mapel: '',
        status: false,
        id_nilai: '',
    },
    methods:{
        // user
        editUser: function(id){
            axios
            .get(this.url+"/userDetail/"+id)
            .then( res => {
                this.id_user = res.data.id;
                this.email = res.data.e_mail;
                this.role = res.data.role;
                this.password = this.decryptPass(res.data.password);
            })
            .catch( err => {
                console.log(err);
            });
        },
        decryptPass: function(pass){
            axios
            .get(this.url+"/decryptPass/"+pass)
            .then(res => {
                this.pass_decrypt = res.data;
            })
            .catch(err => {
                console.log(err);
            });
        },
        deleteUser: function(id,email){
            Swal.fire({
                title: email+' akan di hapus?',
                text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    axios.get(this.url+"/deleteUser/"+id).then(res => {
                        if(res.data.status == 'sukses'){
                                const Toast = Swal.mixin({
                                    toast: true,
                                    position: 'top-end',
                                    showConfirmButton: false,
                                    timer: 2000,
                                    timerProgressBar: true,
                                    didOpen: (toast) => {
                                        toast.addEventListener('mouseenter', Swal.stopTimer)
                                        toast.addEventListener('mouseleave', Swal.resumeTimer)
                                    },
                                    didClose: (toast) => {
                                        location.reload();
                                    }
                                })

                                Toast.fire({
                                    icon: 'success',
                                    title: 'E-mail '+res.data.data.e_mail+' has been deleted.'
                                })
                            }
                        })
                        .catch(err => {
                            console.log(err);
                        });
                    }
                })
            },
            userActivasi: function(id_login , role){
                axios.get(this.url+"/manageUser/"+role)
                    .then(res => {
                        this.detil_role = res.data;
                        this.id_user = id_login;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            userDeactivasi: function(id_login, role, email){
                Swal.fire({
                    title: email+' akan di non aktifkan?',
                    icon: 'info',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, Non Active Now!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deactivasi/"+id_login+"/"+role)
                            .then(res => {
                                if(res.data.status == 'sukses'){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'E-mail '+res.data.email[0].e_mail+' berhasil di non aktifkan.'
                                    })
                                }
                            }).catch( err => {
                                console.log(err);
                            })
                    }
                })
            },
            // end user
            
            // siswa
            setnis: function(){
                axios.get(this.url+"/getUrutSiswa")
                .then(res => {
                    var tahun = new Date().getFullYear();
                    var bulan = new Date().getMonth();
                    var noUrut = res.data+1;
                    this.nis = tahun+"0"+bulan+"00"+noUrut;
                }).catch(err => {
                    console.log(err);
                });
            },
            editSiswa: function(id){
                axios.get(this.url+"/siswaDetail/"+id)
                .then(res => {
                    let data = res.data;
                    this.nis = data.nis;
                    this.id_siswa = data.id_siswa;
                    this.nama_siswa = data.nama_siswa;
                    this.alamat_siswa = data.alamat;
                    this.kelas = data.kelas;
                    this.jurusan = data.jurusan;
                }).catch(err => {
                    console.log(err);
                });
            },
            hapusSiswa: function(id,nama){
                Swal.fire({
                    title: nama+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deleteSiswa/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Nama siswa '+res.data.nama[0].nama_siswa+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },
            // end siswa

            // mapel
            editMapel: function(id){
                axios.get(this.url+"/detilMapel/"+id)
                    .then(res => {
                        this.nama_mapel = res.data.nama_mapel;
                        this.kode_mapel = res.data.kode_mapel;
                        this.id_mapel = res.data.id;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            hapusMapel: function(id, nama_mapel){
                Swal.fire({
                    title: nama_mapel+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deleteMapel/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Mapel '+res.data.nama_mapel+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },

            // guru
            editGuru: function(id){
                axios.get(this.url+"/detilGuru/"+id)
                    .then(res => {
                        this.nip = res.data.nip;
                        this.nama_guru = res.data.nama_guru_mapel;
                        this.pengampu_mapel = res.data.pengampu_mapel;
                        this.alamat_guru = res.data.alamat;
                        this.arry_pengampu_mapel = this.pengampu_mapel.split(',');
                        this.id_guru = res.data.id_guru_mapel;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            hapusGuru: function(id, guru_nama){
                Swal.fire({
                    title: guru_nama+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deleteGuru/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Guru '+res.data.nama_guru[0].nama_guru_mapel+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },

            // wali kelas
            detilWaliKelas: function(id){
                axios.get(this.url+"/detilWaliKelas/"+id)
                    .then(res => {
                        // console.log(res.data);
                        this.nip_wali_kelas = res.data.nip;
                        this.id_wali_kelas = res.data.id_wali_kelas;
                        this.kelas_wali = res.data.pengampu_kelas;
                        this.jurusan_wali = res.data.pengampu_jurusan;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            hapusWaliKelas: function(id,nip){
                Swal.fire({
                    title: nip+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deleteWaliKelas/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Wali Kelas nip '+res.data.nama_guru[0].nip+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },
            // jurusan

            editJurusan: function(id){
                axios.get(this.url+"/getDetilJurusan/"+id)
                    .then(res => {
                        this.id_jurusan = res.data.id;
                        this.kode_jurusan = res.data.kode_jurusan;
                        this.nama_jurusan = res.data.nama_jurusan;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            hapusJurusan: function(id, nama_jurusan){
                Swal.fire({
                    title: nama_jurusan+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/deleteJurusan/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Jurusan '+nama_jurusan+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },

            // rombel
            getRombel: function(id){
                axios.get(this.url+"/getDetilRombel/"+id)
                    .then(res => {
                        this.id_rombel = res.data.id;
                        this.kode_rombel = res.data.kode_rombel;
                        this.jurusan_rombel = res.data.id_jurusan;
                        this.kelas_rombel = res.data.kelas;
                        this.wali_kelas_rombel = res.data.id_wali_kelas;
                        this.mapel_rombel = res.data.id_mapel.split(',');
                        this.tahun_ajar = res.data.tahun_ajar;
                        this.semester = res.data.semester;
                        console.log(res.data);
                    }).catch(err => {

                    })
            },
            deleteRombel: function(id,kode_rombel){
                Swal.fire({
                    title: 'kode rombel : '+kode_rombel+' akan di hapus?',
                    text: "Data yang sudah di hapus tidak bisa di kembalikan!",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        axios.get(this.url+"/hapusRombel/"+id)
                            .then(res => {
                                if(res.data.status == "sukses"){
                                    const Toast = Swal.mixin({
                                        toast: true,
                                        position: 'top-end',
                                        showConfirmButton: false,
                                        timer: 2000,
                                        timerProgressBar: true,
                                        didOpen: (toast) => {
                                            toast.addEventListener('mouseenter', Swal.stopTimer)
                                            toast.addEventListener('mouseleave', Swal.resumeTimer)
                                        },
                                        didClose: (toast) => {
                                            location.reload();
                                        }
                                    })

                                    Toast.fire({
                                        icon: 'success',
                                        title: 'Kode Rombel '+kode_rombel+' berhasil di hapus.'
                                    })
                                }
                            }).catch(err => {
                                console.log(err);
                            })
                    }
                })
            },
            getDetilMapel: function(id)
            {
                axios.get(this.url+"/getDetilMapel/"+id)
                    .then(res => {
                        this.kode_mapel_detil = res.data.kode_mapel;
                        this.nama_mapel_detil = res.data.nama_mapel;
                        this.nilai_id_mapel = res.data.id;
                    }).catch(err => {
                        console.log(err);
                    })
            },
            saveNilai: function(id_siswa)
            {
                axios.post(this.url+"/saveNilai", {
                    id_guru_mapel: <?php echo e(session('id_user')); ?>,
                    id_mapel: this.nilai_id_mapel,
                    id_siswa: id_siswa,
                    nama_nilai: this.nama_nilai,
                    nilai_angka: this.nilai_angka,
                    nilai_huruf: this.nilai_huruf,
                }).then(res => {
                    console.log(res.data);
                    if(res.data.status == 'sukses'){
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 2000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            },
                            didClose: (toast) => {
                                window.location.replace("<?php echo e(url('/nilai')); ?>");
                            }
                        })

                        Toast.fire({
                            icon: 'success',
                            title: 'Nilai Berhasil di Tambahkan'
                        })
                    }
                }).catch(err => {
                    console.log(err);
                })
            },
            updateNilai: function(id_siswa){
                axios.post(this.url+"/updateNilai/"+this.id_nilai, {
                    id_guru_mapel: <?php echo e(session('id_user')); ?>,
                    id_mapel: this.nilai_id_mapel,
                    id_siswa: id_siswa,
                    nama_nilai: this.nama_nilai,
                    nilai_angka: this.nilai_angka,
                    nilai_huruf: this.nilai_huruf,
                }).then(res => {
                    // console.log(res.data);
                    if(res.data.status == 'sukses'){
                        const Toast = Swal.mixin({
                            toast: true,
                            position: 'top-end',
                            showConfirmButton: false,
                            timer: 2000,
                            timerProgressBar: true,
                            didOpen: (toast) => {
                                toast.addEventListener('mouseenter', Swal.stopTimer)
                                toast.addEventListener('mouseleave', Swal.resumeTimer)
                            },
                            didClose: (toast) => {
                                window.location.replace("<?php echo e(url('/nilai')); ?>");
                            }
                        })

                        Toast.fire({
                            icon: 'success',
                            title: 'Nilai Berhasil di Ubah'
                        })
                    }
                }).catch(err => {
                    console.log(err);
                })
            },
            getDetilNilaiSiswa: function(id_mapel, id_siswa){
                axios.get(this.url+'/NilaiSiswaDetil/'+id_mapel+'/'+id_siswa)
                .then(res => {
                    if(res.data.status == 'gagal'){
                        this.status = false;
                    } else {
                        this.status = true;
                        this.getDetilMapel(res.data.data.id_mapel);
                        this.nama_nilai = res.data.data.nama_nilai;
                        this.nilai_angka = res.data.data.nilai;
                        this.nilai_huruf = res.data.data.nilai_huruf;
                        this.id_nilai = res.data.data.id_nilai;
                        console.log(this.id_nilai);
                    }
                }).catch(err => {
                    console.log(err);
                });
            },
            reset: function(){
                this.getDetilMapel(0);
                this.nama_nilai = '';
                this.nilai_angka = '';
                this.nilai_huruf = '';
            },
            getNilaiHuruf: function(nilai)
            {
                if(nilai >= 80){
                    this.nilai_huruf = 'A';
                } else if(nilai >= 75 && nilai <= 79){
                    this.nilai_huruf = 'B+';
                } else if(nilai >= 65 && nilai <= 79){
                    this.nilai_huruf = 'B';
                } else if(nilai >= 55 && nilai <= 64){
                    this.nilai_huruf = 'C+';
                } else if (nilai >= 50 && nilai <= 54){
                    this.nilai_huruf = 'C';
                } else if(nilai >= 30 && nilai <= 49){
                    this.nilai_huruf = 'D';
                } else {
                    this.nilai_huruf = 'E'
                }

                return this.nilai_huruf;
            },
            cek(){
                alert('sukses');
            }
        },
        mounted(){
            this.getNilaiHuruf(this.nilai_angka);
        }
    });
</script>
<?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/library/vue.blade.php ENDPATH**/ ?>