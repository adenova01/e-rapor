<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">
            
            <?php if(session('message')): ?>
                <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Data Siswa</strong>
                </div>
                <div class="card-body">

                    <?php if(session('role') == 'admin'): ?>
                    <button v-on:click="setnis" class="btn btn-info btn-sm mb-3" data-toggle="modal" data-target="#staticModal"><i class="fa fa-user-plus"></i> Tambah Siswa</button>
                    <?php endif; ?>

                    <table id="myTable" class="table table-striped table-bordered">
                        <thead class="thead-dark">
                            <tr>
                                <th>NIS</th>
                                <th>Nama Siswa</th>
                                <th>Kelas</th>
                                <th>Jurusan</th>
                                <th>Alamat</th>
                                <th>Rombel</th>
                                <?php if(session('role') == 'admin'): ?>
                                <th>Opsi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nis); ?></td>
                                    <td><?php echo e($item->nama_siswa); ?></td>
                                    <td><?php echo e($item->kelas); ?></td>
                                    <td><?php echo e($item->nama_jurusan); ?></td>
                                    <td><?php echo e($item->alamat); ?></td>
                                    <td class="text-center"><?php echo e($item->rombel_id); ?></td>
                                    <?php if(session('role') == 'admin'): ?>
                                    <td>
                                        <button v-on:click="editSiswa(<?php echo e($item->id_siswa); ?>)" data-toggle="modal" data-target="#modalEdit" class="btn btn-outline-warning btn-sm m-2"><i class="fa fa-edit"></i> Ubah</button>
                                        <button v-on:click="hapusSiswa(<?php echo e($item->id_siswa); ?>,'<?php echo e($item->nama_siswa); ?>')" class="btn btn-outline-danger btn-sm m-2"><i class="fa fa-trash"></i> Hapus</button>
                                        <button v-on:click="id_siswa = <?php echo e($item->id_siswa); ?>" data-toggle="modal" data-target="#modalAddRombel" class="btn btn-outline-info btn-sm m-2"><i class="fa fa-plus"></i> Add / Edit Rombel</button>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    

    <div class="modal fade" id="staticModal" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Siswa</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('saveSiswa')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nis" type="text" id="nis" name="nis" placeholder="Nis" class="form-control" required readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input type="text" id="Nama" name="Nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Kelas..." name="kelas" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XII</option>
                                        <option value="XIII">XIII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="jurusan" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea type="text" id="alamat" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="reset" class="btn btn-danger btn-sm">Reset</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    

    <div class="modal fade" id="modalEdit" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Edit Siswa</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('editSiswa/')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" v-model="id_siswa" name="id"/>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-user-o" aria-hidden="true"></i></div>
                                    <input v-model="nis" type="text" id="nis1" name="nis" placeholder="Nis" class="form-control" required readonly>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-address-card-o" aria-hidden="true"></i></div>
                                    <input v-model="nama_siswa" type="text" id="Nama1" name="Nama" placeholder="Nama" class="form-control" required>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="kelas" data-placeholder="Choose a Kelas..." data-width="100%" name="kelas" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <option value="X">X</option>
                                        <option value="XII">XI</option>
                                        <option value="XIII">XII</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <select v-model="jurusan" data-placeholder="Choose a Jurusan..." data-width="100%" name="jurusan" class="js-example-basic-single" required>
                                        <?php $id_jurusan = "{{jurusan}}" ?>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php echo e($id_jurusan == $item->id ? 'selected' : ''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->nama_jurusan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-addon"><i class="fa fa-map-marker" aria-hidden="true"></i></div>
                                    <textarea v-model="alamat_siswa" type="text" id="alamat1" name="alamat" placeholder="Alamat" class="form-control" required></textarea>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Update</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    

    

    

    <div class="modal fade" id="modalAddRombel" tabindex="-1" role="dialog" aria-labelledby="staticModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="card">
                    <div class="card-header">Add Rombel</div>
                    <div class="card-body card-block">
                        <form action="<?php echo e(url('addRombel')); ?>" method="post" class="">
                            <?php echo csrf_field(); ?>

                            <input type="hidden" name="id_siswa" v-model="id_siswa" />

                            <div class="form-group">
                                <div class="input-group">
                                    <select data-placeholder="Choose a Jurusan..." name="rombel" data-width="100%" class="js-example-basic-single" required>
                                        <option value="" label="default"></option>
                                        <?php $__currentLoopData = $rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama_rombel); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-actions form-group">
                                <button type="submit" class="btn btn-success btn-sm">Submit</button>
                                <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/siswa.blade.php ENDPATH**/ ?>