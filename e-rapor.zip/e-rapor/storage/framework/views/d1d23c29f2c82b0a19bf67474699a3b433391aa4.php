<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Detil Wali Murid</strong>
                <a href="<?php echo e(url('/wali_murid')); ?>" class="btn btn-primary btn-sm" style="float:right; margin-right: 15px"><span class="fa fa-arrow-left"></span> back</a>
            </div>
            <div class="card-body">
                <table class="table">
                    <tbody>
                        <tr>
                            <th class="col-2">Nama Wali Murid</th>
                            <td class="col-1">:</td>
                            <td><?php echo e($walimurid->nama_wali_murid); ?></td>
                        </tr>
                        <tr>
                            <th>Nama Siswa</th>
                            <td>:</td>
                            <td><?php echo e($siswa->nama_siswa); ?></td>
                        </tr>
                        <tr>
                            <th>Kelas</th>
                            <td>:</td>
                            <td><?php echo e($siswa->kelas); ?></td>
                        </tr>
                        <tr>
                            <th>Jurusan</th>
                            <td>:</td>
                            <td><?php echo e($siswa->nama_jurusan); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/detil_wali_murid.blade.php ENDPATH**/ ?>