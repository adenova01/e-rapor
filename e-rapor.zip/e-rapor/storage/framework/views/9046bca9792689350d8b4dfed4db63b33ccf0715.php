<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-sm-12">

            <div class="container">
                <div class="row gutters">
                    <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
                        <div class="card h-100">
                            <div class="card-body">
                                <div class="account-settings">
                                    <div class="user-profile">
                                        <div class="user-avatar">
                                            <img src="<?php echo e(url('storage/avatar/default.jpg')); ?>" alt="Maxwell Admin">
                                        </div>
                                        <h5 class="user-name"><?php echo e(session('role')); ?></h5>
                                        <h6 class="user-email"><?php echo e(session('email')); ?></h6>
                                    </div>
                                    <div class="about">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12">
                        <div class="card h-100">
                            <div class="card-body">
                                <?php if(session('message')): ?>
                                    <div class="alert alert-info"><?php echo e(session('message')); ?></div>
                                <?php endif; ?>
                                <form action="/changePass/<?php echo e(session('id')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="row gutters">
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="form-group">
                                            <label for="fullName">Email</label>
                                            <input type="email" readonly class="form-control" id="fullName" placeholder="Enter full name" value="<?php echo e(session('email')); ?>">
                                        </div>
                                    </div>
                                    <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="form-group">
                                            <label>Password</label>
                                            <div class="input-group" id="show_hide_password">
                                              <input class="form-control" name="password" type="password" value="<?php echo e($passdecrypt); ?>">
                                              <div class="input-group-addon">
                                                <a href=""><i class="fa fa-eye-slash" aria-hidden="true"></i></a>
                                              </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row gutters">
                                    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                                        <div class="text-right">
                                            <button type="submit" class="btn btn-primary">Update</button>
                                        </div>
                                    </div>
                                </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ade/data/programing/laravel/e-rapor/resources/views/page/user_detil.blade.php ENDPATH**/ ?>