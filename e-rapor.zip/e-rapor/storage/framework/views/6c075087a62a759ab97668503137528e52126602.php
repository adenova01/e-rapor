<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-sm-12">
        
        <?php if(session('message')): ?>
            <div class="alert alert-info text-center"><?php echo e(session('message')); ?></div>
        <?php endif; ?>
        <div class="card">
            <div class="card-header">
                <strong class="card-title">Data Nilai</strong>
            </div>
            <div class="card-body">
                <table id="myTable" class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>NIS</th>
                            <th>Nama Siswa</th>
                            <th>Kelas</th>
                            <th>Jurusan</th>
                            <th>Kode Rombel</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $siswa_rombel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                            <tr>
                                <td><?php echo e($item->nis); ?></td>
                                <td><?php echo e($item->nama_siswa); ?></td>
                                <td><?php echo e($item->kelas); ?></td>
                                <td><?php echo e($item->nama_jurusan); ?></td>
                                <td><?php echo e($item->kode_rombel); ?></td>
                                <td>
                                    <?php if(session('role') == 'guru'): ?>
                                        <a href="<?php echo e(url('/isiNilai'.'/'.$item->id_siswa)); ?>" class="btn btn-outline-primary btn-sm m-2"><i class="fa fa-pencil"></i> Detil</a>
                                    <?php endif; ?>
                                    <a href="<?php echo e(url('/detilNilai'.'/'.$item->id_siswa)); ?>" class="btn btn-outline-success btn-sm m-2"><i class="fa fa-eye"></i> Nilai</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/e-rapor/resources/views/page/nilai.blade.php ENDPATH**/ ?>